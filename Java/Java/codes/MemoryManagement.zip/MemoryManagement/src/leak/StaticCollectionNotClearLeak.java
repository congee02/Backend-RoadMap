package leak;

import java.util.ArrayList;
import java.util.List;

public class StaticCollectionNotClearLeak {

    private static List<String> sharedList = new ArrayList<>();


    public static void main(String[] args) {
        for (int i = 0 ; i < 1_000_000 ; i ++ ) {
            addItemToSharedList("Item " + i);
        }
        System.out.println("Items added to the sharedList.");

        // 在这里没有对sharedList进行清理或重置为null
        // 因此，在main方法结束后，sharedList依然引用着大量的String对象
    }

    public static void addItemToSharedList(String value) {
        sharedList.add(value);
    }
}