package leak;

import java.util.ArrayList;
import java.util.List;

public class AnonymousInnerClassLeak {

    public static void main(String[] args) {
        new AnonymousInnerClassLeak().doSomething();
    }

    public void doSomething() {
        // 假设从这里获取了数据
        final List<String> data = fetchData();

        // 创建匿名内部类，持有对外部 data 的引用
        // 匿名内部类使用外部 data
        final Runnable processDataRunnable = () -> processData(data);

        // 模拟将匿名内部类对象传给其他线程或异步任务执行
        final Thread thread = new Thread(processDataRunnable);
        thread.start();

        // 假设这里不再需要 processDataRunnable 对象，
        // 但由于 processDataRunnable 持有堆对 data 的引用
        // data 无法被垃圾回收器回收，造成内存泄漏
    }

    private void processData(List<String> data) {
        data.stream().forEach(System.out::println);
    }

    private List<String> fetchData() {
        final ArrayList<String> data = new ArrayList<>();
        for (int i = 0 ; i < 1_000 ; i ++ ) {
            data.add("data " + i);
        }
        return data;
    }

}
