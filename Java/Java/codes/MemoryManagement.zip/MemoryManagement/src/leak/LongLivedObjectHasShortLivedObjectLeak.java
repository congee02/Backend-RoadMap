package leak;

public class LongLivedObjectHasShortLivedObjectLeak {

    private LivedObject longLivedObject;

    public LongLivedObjectHasShortLivedObjectLeak() {
        longLivedObject = new LivedObject();
    }

    public void doSomething() {
        final LivedObject shortLivedObject = new LivedObject();
        longLivedObject.setLivedObject(shortLivedObject);

        // 其他操作

        // 此时，longLivedObject 持有 shortLivedObject 的引用
        // 即使在 doSomething 方法执行结束后，shortLivedObject 可能不再被使用
        // 由于 shortLivedObject 还在被 LongLivedObject 引用着，垃圾回收器无法回收 shortLivedObject，造成内存泄漏

    }

    private static class LivedObject {
        private LivedObject livedObject;

        public void setLivedObject(LivedObject livedObject) {
            this.livedObject = livedObject;
        }
    }
}
