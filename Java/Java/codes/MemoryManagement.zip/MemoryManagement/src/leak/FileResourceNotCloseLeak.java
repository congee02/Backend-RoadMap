package leak;

import util.FileUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileResourceNotCloseLeak {

    public static void main(String[] args) {
        File file = null;
        try {
            file = FileUtils.createFileIfNecessary("sample.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            final Scanner scanner = new Scanner(new FileReader(file));
            while (scanner.hasNext()) {
                System.out.println(scanner.nextLine());
            }
            // 没有关闭 FileReader 和 scanner，会造成文件资源泄漏
            // reader.close() 或者 使用 try-with-resource 来确保资源关闭
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

}
