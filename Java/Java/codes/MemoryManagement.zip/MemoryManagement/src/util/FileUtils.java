package util;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public final class FileUtils {

    private FileUtils() {}

    public static File createFileIfNecessary(String pathname) throws IOException {
        File file = new File(pathname);
        if (! file.exists()) {
            file.createNewFile();
            PrintWriter fileWriter = new PrintWriter(file);
            fileWriter.println("Create Time: " + new Date());
            fileWriter.close();
        }
        return file;
    }

}
