package management;

import sample.Student;

public class ForceGarbageCollectionManagement {

    public static void main(String[] args) {
        // 创建一个对象 student
        Student student = new Student();

        // 将 student 设置为 null，原来的对象没有引用指向，但并不一定立即被垃圾回收器回收
        student = null;

        // 强制进行垃圾回收
        System.gc();

        // 由于强制进行垃圾回收，该对象可能被垃圾回收器回收
    }

}
