package management;

import sample.Student;

public class ObjectCreateAndRecycleManagement {

    public static void main(String[] args) {
        // 创建一个对象
        Student s1 = new Student();

        // 创建另一个对象，并将其引用赋值给 s2
        Student s2 = new Student();

        // s2 的引用指向新的对象，原先的对象没有引用指向，将会被垃圾回收器回收。
        s2 = s1;

        // 手动设置 s1 为 null，该对象没有引用指向，将会被垃圾回收器回收
        s1 = null;

        // 此前原先的对象没有引用指向，将会被垃圾回收器回收
        s2 = null;

        // 由于 s1 和 s2 都已经被设置为 null，垃圾回收器会回收它们原先指向的对象
    }

}
