package management;

import util.FileUtils;

import java.io.*;
import java.util.Date;
import java.util.Scanner;

public class TryWithResourceManagement {

    public static void main(String[] args) {
        File file = null;
        try {
            file = FileUtils.createFileIfNecessary("sample.txt");
        } catch (IOException e) {
            throw new RuntimeException("创建文件失败。");
        }

        // try-with-resource
        try (PrintWriter printWriter = new PrintWriter(new FileWriter(file, true))) {
            printWriter.println("Append Time: " + new Date());
            // try 块结束后，printWriter 和 FileWriter 自动关闭，无需手动调用 close
        } catch (IOException e) {
            e.printStackTrace();
        }

        // try-with-resource
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            Scanner scanner = new Scanner(reader);
            while (scanner.hasNext()) {
                System.out.println(scanner.nextLine());
            }
            // try 块结束后，FileReader 和 reader 和 scanner 自动关闭，无需手动调用 close
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
