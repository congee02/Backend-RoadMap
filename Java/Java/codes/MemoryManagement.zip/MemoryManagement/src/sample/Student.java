package sample;

public class Student {
    private Long stuId;
    private String stuName;

    public Student(Long stuId, String stuName) {
        this.stuId = stuId;
        this.stuName = stuName;
    }

    public Student() {
        this(0L, "default-name");
    }

    public Long getStuId() {
        return stuId;
    }

    public void setStuId(Long stuId) {
        this.stuId = stuId;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }
}
