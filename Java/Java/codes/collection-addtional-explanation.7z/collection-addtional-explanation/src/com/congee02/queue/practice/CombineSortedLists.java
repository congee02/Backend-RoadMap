package com.congee02.queue.practice;

import com.congee02.queue.practice.utils.InputGenerateUtils;

import java.util.*;

/**
 * 合并 k 个有序数组
 */
public class CombineSortedLists {

    private static List<List<Integer>> randomSortedListList() {
        List<List<Integer>> listList = InputGenerateUtils.randomIntegerListList();
        for (List<Integer> list : listList) {
            Collections.sort(list);
            System.out.println(list);
        }
        return listList;
    }

    public static List<Integer> combineSortedLists(List<List<Integer>> listList) {
        int size = listList.size();
        int internalSizeTotal = 0;
        int internalSizeMax = -1;
        int[] sizeCache = new int[size];
        for (int i = 0 ; i < size ; i ++ ) {
            sizeCache[i] = listList.get(i).size();
            internalSizeMax = Math.max(internalSizeMax, sizeCache[i]);
            internalSizeTotal += sizeCache[i];
        }
        PriorityQueue<Integer> queue = new PriorityQueue(internalSizeTotal);
        for (int j = 0 ; j < internalSizeMax ; j ++ ) {
            for (int i = 0 ; i < size ; i ++ ) {
                if (j >= sizeCache[i]) {
                    continue;
                }
                queue.add(listList.get(i).get(j));
            }
        }
        ArrayList<Integer> result = new ArrayList<>();
        while (! queue.isEmpty()) {
            result.add(queue.poll());
        }
        return result;
    }

    public static void main(String[] args) {
        List<List<Integer>> listList = randomSortedListList();
        System.out.println(combineSortedLists(listList));
    }

}
