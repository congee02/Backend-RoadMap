package com.congee02.queue.practice.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public final class InputGenerateUtils {

    private InputGenerateUtils() {}

    private final static int DEFAULT_SIZE = 10;
    private final static int DEFAULT_BOUND = 100;

    public static List<Integer> randomIntegerList(int size, int bound) {
        Random random = new Random();
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0 ; i < size ; i ++ ) {
            list.add(random.nextInt(bound));
        }
        return list;
    }

    public static List<Integer> randomIntegerList(int size) {
        return randomIntegerList(size, DEFAULT_BOUND);
    }

    public static List<Integer> randomIntegerList() {
        return randomIntegerList(DEFAULT_SIZE, DEFAULT_SIZE);
    }

    public static List<List<Integer>> randomIntegerListList(int listListSize, int listSize, int bound) {
        List<List<Integer>> listList = new ArrayList<>();
        for (int i = 0 ; i < listListSize ; i ++ ) {
            listList.add(randomIntegerList(listSize, bound));
        }
        return listList;
    }

    public static List<List<Integer>> randomIntegerListList() {
        return randomIntegerListList(DEFAULT_SIZE, DEFAULT_SIZE, DEFAULT_BOUND);
    }

}
