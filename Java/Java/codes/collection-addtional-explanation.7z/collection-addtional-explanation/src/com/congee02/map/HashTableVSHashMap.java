package com.congee02.map;

import java.util.HashMap;
import java.util.Hashtable;

public class HashTableVSHashMap {

    private final static HashMap<String, String> map = new HashMap<>();
    private final static Hashtable<String, String> table = new Hashtable<>();

    private static void nullKeyNullValueSupport() {
        System.out.println("===== HashMap Supports Null Key and Null Value =====");
        map.put(null, "NullKey->Value");
        map.put("Key->NullValue", null);
        System.out.println(map);
        System.out.println("===== HashTable doesn't Supports Null Key and Null Value =====");
        try {
            table.put(null, "NullKey->Value");
            System.out.println(table);
        } catch (NullPointerException e) {
            System.err.println("HashTable 不支持 NullKey");
        }
        try {
            table.put("Key->NullValue", null);
            System.out.println(table);
        } catch (NullPointerException e) {
            System.err.println("HashTable 不支持 NullValue");
        }

        map.clear();
        table.clear();
    }

    public static void main(String[] args) {
        nullKeyNullValueSupport();
    }

}
