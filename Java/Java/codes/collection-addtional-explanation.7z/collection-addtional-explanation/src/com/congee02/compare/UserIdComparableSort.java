package com.congee02.compare;

import java.util.Objects;
import java.util.TreeMap;
import java.util.TreeSet;

public class UserIdComparableSort {
    private static class ComparableUser implements Comparable<ComparableUser> {
        private Integer id;
        private String name;

        public ComparableUser(Integer id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String toString() {
            return "User{" +
                    "id=" + id +
                    ", name='" + name + '\'' +
                    '}';
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            UserIdComparableSort.ComparableUser user = (UserIdComparableSort.ComparableUser) o;
            return Objects.equals(id, user.id) && Objects.equals(name, user.name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(id, name);
        }

        @Override
        public int compareTo(ComparableUser o) {
            return this.id - o.id;
        }
    }

    public static void main(String[] args) {
        TreeSet<ComparableUser> comparableUserTreeSet = new TreeSet<>();
        for (int i = 0 ; i < 100 ; i ++ ) {
            comparableUserTreeSet.add(new ComparableUser(i, "user " + i));
        }
        for (ComparableUser user : comparableUserTreeSet) {
            System.out.println(user);
        }
    }

}
