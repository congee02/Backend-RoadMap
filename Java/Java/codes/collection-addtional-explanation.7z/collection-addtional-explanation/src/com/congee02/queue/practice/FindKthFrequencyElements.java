package com.congee02.queue.practice;

import com.congee02.queue.practice.utils.InputGenerateUtils;

import java.util.*;

/**
 * 找出 K 个频率最高的元素
 */
public class FindKthFrequencyElements {

    private static List<Integer> randomElementList() {
        return InputGenerateUtils.randomIntegerList(20, 10);
    }

    private static class ElementFrequency<E> {
        private E element;
        private int count;

        public ElementFrequency(E element) {
            this.element = element;
            this.count = 0;
        }

        public ElementFrequency(E element, int count) {
            this.element = element;
            this.count = count;
        }

        @Override
        public String toString() {
            return "ElementFrequency{" +
                    "element=" + element +
                    ", count=" + count +
                    '}';
        }
    }

    private static List<ElementFrequency> findKthFrequencyElements(List<Integer> list, int k) {
        if (k < 1) {
            throw new IllegalArgumentException("k < 1.");
        }
        if (list.isEmpty()) {
            throw new IllegalArgumentException("num is empty.");
        }
        if (list.size() == 1) {
            return List.of(new ElementFrequency(list.get(0), 1));
        }
        Map<Integer, Integer> elementCount = new HashMap<>() {
            @Override
            public Integer put(Integer key, Integer value) {
                if (! this.containsKey(key)) {
                    return super.put(key, 1);
                }
                Integer oldValue = super.get(key);
                return super.put(key, oldValue + 1);
            }
        };
        list.forEach(e -> {
            elementCount.put(e, null);
        });
        PriorityQueue<Map.Entry<Integer, Integer>> queue
                = new PriorityQueue<>(elementCount.size(), (o1, o2) -> o2.getValue() - o1.getValue());
        Set<Map.Entry<Integer, Integer>> entries = elementCount.entrySet();
        queue.addAll(entries);
        ArrayList<ElementFrequency> result = new ArrayList<>(Math.min(k, entries.size()));
        for (int i = 0 ; i < k && ! queue.isEmpty() ; i ++ ) {
            Map.Entry<Integer, Integer> entry = queue.poll();
            result.add(new ElementFrequency(entry.getKey(), entry.getValue()));
        }
        return result;
    }

    public static void main(String[] args) {
        findKthFrequencyElements(randomElementList(), 10)
                .forEach(System.out::println);
    }

}
