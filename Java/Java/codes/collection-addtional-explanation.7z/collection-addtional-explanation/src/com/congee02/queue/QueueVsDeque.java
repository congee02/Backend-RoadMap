package com.congee02.queue;

import java.util.*;

public class QueueVsDeque {

    private final static Queue<Object> queue = new LinkedList<>();
    private final static Deque<Object> deque = new ArrayDeque<>();

    private static void queueDemo() {
        queue.offer(1);
        queue.offer("World");
        queue.offer("Hello");
        System.out.println("Queue: ");
        while (! queue.isEmpty()) {
            System.out.println(queue.poll() + "");
        }
    }

    private static void dequeDemo() {
        deque.offerFirst("Hello");
        deque.offerLast("World");
        deque.offer("!");   // 默认插入到队尾
        System.out.println("Deque: ");
        while (! deque.isEmpty()) {
            System.out.println(deque.removeFirst());
        }
    }

    public static void main(String[] args) {
        System.out.println("===== Queue =====");
        queueDemo();
        System.out.println("===== Deque =====");
        dequeDemo();
    }

}
