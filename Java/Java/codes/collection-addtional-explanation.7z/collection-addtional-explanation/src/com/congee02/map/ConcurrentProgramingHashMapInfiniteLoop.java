package com.congee02.map;

import java.util.HashMap;

public class ConcurrentProgramingHashMapInfiniteLoop {

    private static final HashMap<Integer, String> map = new HashMap<>();

    private static final Runnable putRunnable = () -> {
        while (true) {
            for (int i = 0 ; i < 1_000_000 ; i ++ ) {
                map.put(i, "Value " + i);
            }
        }
    };

    private static final Runnable checkContainRunnable = () -> {
        while (true) {
            for (int i = 0 ; i < 1_000_000 ; i ++ ) {
                if (! map.containsKey(i)) {
                    System.out.println("Key " + i + " is missing.");
                }
            }
        }
    };

    public static void main(String[] args) {
        new Thread(putRunnable).start();
        new Thread(checkContainRunnable).start();
    }

}
