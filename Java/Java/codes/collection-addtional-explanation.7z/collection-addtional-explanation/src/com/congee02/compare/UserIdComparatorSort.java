package com.congee02.compare;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

public class UserIdComparatorSort {

    private static class User {
        private Integer id;
        private String name;

        public User(Integer id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String toString() {
            return "User{" +
                    "id=" + id +
                    ", name='" + name + '\'' +
                    '}';
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            User user = (User) o;
            return Objects.equals(id, user.id) && Objects.equals(name, user.name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(id, name);
        }
    }

    private static List<User> unsortedUserList() {
        HashSet<User> userHashSet = new HashSet<>();
        for (int i = 0 ; i < 100 ; i ++ ) {
            userHashSet.add(new User(i, "user " + i));
        }
        ArrayList<User> userArrayList = new ArrayList<>(userHashSet);
        return userArrayList;
    }

    public static void main(String[] args) {
        List<User> userList = unsortedUserList();
        System.out.println("===== unsorted =====");
        userList.forEach(System.out::println);
        userList.sort((o1, o2) -> o1.id - o2.id);
        System.out.println("===== sorted =====");
        userList.forEach(System.out::println);
    }

}
