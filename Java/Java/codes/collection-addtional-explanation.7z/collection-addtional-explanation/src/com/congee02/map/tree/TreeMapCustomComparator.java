package com.congee02.map.tree;

import java.util.*;

public class TreeMapCustomComparator {

    private static class CustomKey {
        private String name;
        private Integer id;

        public CustomKey(String name, Integer id) {
            this.name = name;
            this.id = id;
        }

        @Override
        public String toString() {
            return "CustomKey{" +
                    "name='" + name + '\'' +
                    ", id=" + id +
                    '}';
        }
    }

    private static List<CustomKey> randomUnsortedCustomKey(int size) {
        HashSet<CustomKey> set = new HashSet<>(size);
        for (int i = 0 ; i < size ; i ++ ) {
            set.add(new CustomKey("customKey " + i, i));
        }
        return new ArrayList<>(set);
    }

    public static void main(String[] args) {
        int size = 5;
        List<CustomKey> keys = randomUnsortedCustomKey(size);
        TreeMap<CustomKey, String> treeMap = new TreeMap<>(Comparator.comparingInt(k -> k.id));
        for (int i = 0 ; i < size ; i ++ ) {
            treeMap.put(keys.get(i), "value " + i);
        }
        System.out.println(treeMap);
    }

}