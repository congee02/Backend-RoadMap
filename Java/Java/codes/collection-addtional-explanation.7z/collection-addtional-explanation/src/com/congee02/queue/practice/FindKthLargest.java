    package com.congee02.queue.practice;

    import java.util.PriorityQueue;

    /**
     * 找到数据中第 k 大的元素
     */
    public class FindKthLargest {

        private static int findKthLargest(int[] num, int k) {
            if (k < 1) {
                throw new IllegalArgumentException("k < 1.");
            }
            if (num.length < 1) {
                throw new IllegalArgumentException("num is empty.");
            }
            if (num.length < k) {
                throw new IllegalArgumentException("num.length < k");
            }
            if (num.length == 1) {
                return num[0];
            }
            PriorityQueue<Integer> priorityQueue
                    = new PriorityQueue<>(num.length, ((o1, o2) -> o2 - o1));
            for (int e : num) {
                priorityQueue.add(e);
            }
            for (int i = 0 ; i < k - 1 ; i ++ ) {
                priorityQueue.poll();
            }
            return priorityQueue.poll();
        }

        public static void main(String[] args) {
            System.out.println(findKthLargest(new int[]{1}, 1));
        }

    }
