package com.congee02.list;

import java.util.*;

/**
 * 普通数组 和 ArrayList 增删改查 操作对比
 */
public class ArrayListVSArray {

    private static void arrayCRUD() {
        String[] strArrays = {"hello", "world", "!"};
        // 通过下标访问并修改
        strArrays[0] = "goodbye";
        System.out.println(Arrays.toString(strArrays)); // 需要借助 Arrays.toString(array) 打印
        // 删除第一个元素
        for (int i = 0 ; i < strArrays.length - 1 ; i ++ ) {
            strArrays[i] = strArrays[i + 1];
        }
        strArrays[strArrays.length - 1] = null;
        System.out.println(Arrays.toString(strArrays));
    }

    private static void arrayListCRUD() {
        ArrayList<String> strList = new ArrayList<>(Arrays.asList("hello", "world", "!"));
        // 向 strList 添加元素
        strList.add(0, "halo");
        strList.add("SanbornCalvin44");
        System.out.println(strList);
        strList.set(1, "fox");
        System.out.println(strList);
        strList.remove(0);
        System.out.println(strList);
        Collections.binarySearch(strList, "fox");
    }

    public static void main(String[] args) {
        System.out.println("===== arrayCRUD =====");
        arrayCRUD();
        System.out.println("===== arrayListCRUD =====");
        arrayListCRUD();
    }

}