package com.congee02.queue.practice;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.function.Function;

/**
 * 寻找前 K 个最接近原点的二维点
 */
public class FindFirstKthClosetPointsToOrigin {

    // 二维点类
    private static class TwoDimensionDot {
        private double x;
        private double y;

        public TwoDimensionDot(double x, double y) {
            this.x = x;
            this.y = y;
        }

        // 计算曼哈顿距离到原点的方法
        public double manhattanDistanceToOrigin() {
            return Math.abs(x) + Math.abs(y);
        }

        // 计算欧几里德距离到原点的方法
        public double euclideanDistanceToOrigin() {
            return Math.sqrt(x * x + y * y);
        }

        @Override
        public String toString() {
            return "TwoDimensionDot{" +
                    "x=" + x +
                    ", y=" + y +
                    '}';
        }
    }

    private static final Random random = new Random();

    // 生成随机的二维点
    private static TwoDimensionDot randomTwoDimensionDot(double xBound, double yBound) {
        return new TwoDimensionDot((random.nextDouble() * xBound) * (random.nextBoolean() ? -1 : 1), random.nextDouble() * yBound * (random.nextBoolean() ? -1 : 1));
    }

    // 生成随机的二维点列表
    private static List<TwoDimensionDot> randomTwoDimensionDotList(double xBound, double yBound, int size) {
        List<TwoDimensionDot> list = new ArrayList<>(size);
        for (int i = 0 ; i < size ; i ++ ) {
            list.add(randomTwoDimensionDot(xBound, yBound));
        }
        return list;
    }

    // 寻找前 K 个最接近原点的点
    private static List<TwoDimensionDot> firstKthClosetPointsToOrigin(List<TwoDimensionDot> dots, int k, Function<TwoDimensionDot, Double> distanceCalculator) {
        int size = dots.size();
        if (k < 1) {
            throw new IllegalArgumentException("k < 1.");
        }
        if (size < 1) {
            throw new IllegalArgumentException("num is empty.");
        }
        if (size < k) {
            throw new IllegalArgumentException("size < k");
        }
        if (size == 1) {
            return List.of(dots.get(0));
        }
        PriorityQueue<TwoDimensionDot> queue = new PriorityQueue<>(size, (o1, o2) -> {
            final double o1d, o2d;
            if ((o1d = distanceCalculator.apply(o1)) == (o2d = distanceCalculator.apply(o2))) {
                return 0;
            } else if (o1d - o2d < 0) {
                return -1;
            }
            return 1;
        });
        queue.addAll(dots);
        ArrayList<TwoDimensionDot> result = new ArrayList<>();
        for (int i = 0; i < k ; i ++ ) {
            result.add(queue.poll());
        }
        return result;
    }

    // 寻找前 K 个最接近原点的点（使用曼哈顿距离）
    private static List<TwoDimensionDot> firstManhattanKthClosetPointsToOrigin(List<TwoDimensionDot> dots, int k) {
        return firstKthClosetPointsToOrigin(dots, k, TwoDimensionDot::manhattanDistanceToOrigin);
    }

    // 寻找前 K 个最接近原点的点（使用欧几里德距离）
    private static List<TwoDimensionDot> firstEuclideanKthClosetPointsToOrigin(List<TwoDimensionDot> dots, int k) {
        return firstKthClosetPointsToOrigin(dots, k, TwoDimensionDot::euclideanDistanceToOrigin);
    }

    public static void main(String[] args) {
        // 生成随机二维点列表
        List<TwoDimensionDot> dots = randomTwoDimensionDotList(20, 20, 20);
        dots.forEach(System.out::println);

        // 寻找前 K 个最接近原点的点（曼哈顿距离）
        System.out.println("===== Manhattan Distance =====");
        firstManhattanKthClosetPointsToOrigin(dots, 3).forEach(System.out::println);

        // 寻找前 K 个最接近原点的点（欧几里德距离）
        System.out.println("===== Euclidean Distance =====");
        firstEuclideanKthClosetPointsToOrigin(dots, 3).forEach(System.out::println);

    }

}
