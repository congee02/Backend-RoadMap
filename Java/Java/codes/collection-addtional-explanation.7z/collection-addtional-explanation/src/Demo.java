import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

public class Demo {

    public static void main(String[] args) {
        HashMap<String, Object> map = new HashMap<>();
        map.forEach((k, v) -> {

        });
        new ConcurrentHashMap<>().clear();
    }

}
