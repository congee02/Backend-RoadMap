package com.congee02.multithread.reentrantlock;

/**
 * synchronized 允许一个线程获取两次锁而不阻塞，
 * 说明 synchronized 也是重入锁
 */
public class AcquireTwiceLock {

    private static final Object lock = new Object();

    private static final Runnable acquireTwoLock = () -> {
        System.out.println("Attempt to acquire for the first time");
        synchronized (lock) {
            System.out.println("Acquire lock for the first time");
            System.out.println("Attempt to acquire for the second time");
            synchronized (lock) {
                System.out.println("Acquire lock for the second time");
            }
        }
    };

    public static void main(String[] args) {
        new Thread(acquireTwoLock).start();
    }

}
