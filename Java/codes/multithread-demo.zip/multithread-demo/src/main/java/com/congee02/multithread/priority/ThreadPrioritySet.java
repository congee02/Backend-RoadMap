package com.congee02.multithread.priority;

public class ThreadPrioritySet {

    private static final Runnable getPriorityRunnable = () -> {
        Thread thread = Thread.currentThread();
        System.out.println("The priority of " + thread.getName() + " is " + thread.getPriority());
    };

    public static void main(String[] args) {

        Thread highPriorityThread = new Thread(getPriorityRunnable, "HighPriorityThread");
        highPriorityThread.setPriority(Thread.NORM_PRIORITY + 3);

        Thread normPriorityThread = new Thread(getPriorityRunnable, "NormPriorityThread");
        normPriorityThread.setPriority(Thread.NORM_PRIORITY);


        Thread lowPriorityThread = new Thread(getPriorityRunnable, "LowPriorityThread");
        lowPriorityThread.setPriority(Thread.NORM_PRIORITY - 3);

        lowPriorityThread.start();
        normPriorityThread.start();
        highPriorityThread.start();

    }

}
