package com.congee02.multithread.ordered;

public final class NaiveLazyLoadSingleton {

    private NaiveLazyLoadSingleton() {}

    private static NaiveLazyLoadSingleton instance;

    public static NaiveLazyLoadSingleton getInstance() {
        if (instance == null) {
            instance = new NaiveLazyLoadSingleton();
        }
        return instance;
    }



}
