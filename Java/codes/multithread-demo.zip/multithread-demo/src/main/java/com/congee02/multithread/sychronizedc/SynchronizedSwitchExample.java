package com.congee02.multithread.sychronizedc;

public class SynchronizedSwitchExample {

    /**
     * 异步电源开关
     */
    private static class SynchronizedPowerSwitch {

        /**
         * volatile: 保证其可见性 & 防止指令重排
         */
        private volatile boolean flag;

        /**
         * synchronized: 只允许一个线程切换开关
         */
        public synchronized void toggleFlag() {
            flag = ! flag;
            System.out.println("toggleFlag: " + "{ NanoTime: " + (System.nanoTime() - baseNanoTime) + "; Thread: " + Thread.currentThread().getName() + "}");
        }

        /**
         * 检查开关
         */
        public boolean check() {
            System.out.println("check: " + "{NanoTime: " + (System.nanoTime() - baseNanoTime) + "; Thread: " + Thread.currentThread().getName() + "}");
            return flag;
        }

    }

    private static final long baseNanoTime = System.nanoTime();

    private static final SynchronizedPowerSwitch powerSwitch = new SynchronizedPowerSwitch();

    private final static Runnable toggleSwitchRunnable = () -> {
        for (int i = 0 ; i < 5 ; i ++ ) {
            powerSwitch.toggleFlag();
        }
    };

    private final static Runnable checkSwitchRunnable = () -> {
        for (int i = 0 ; i < 5 ; i ++ ) {
            powerSwitch.check();
        }
    };

    public static void main(String[] args) {

        Thread toggleThread1 = new Thread(toggleSwitchRunnable, "🔺Toggle");
        Thread toggleThread2 = new Thread(toggleSwitchRunnable, "⚪Toggle");
        toggleThread1.start();
        toggleThread2.start();

        Thread checkThread1 = new Thread(checkSwitchRunnable, "🔺Check");
        Thread checkThread2 = new Thread(checkSwitchRunnable, "⚪Check");
        checkThread1.start();
        checkThread2.start();
    }

}
