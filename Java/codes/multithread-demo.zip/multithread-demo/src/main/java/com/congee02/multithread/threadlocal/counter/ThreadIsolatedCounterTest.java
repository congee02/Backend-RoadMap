package com.congee02.multithread.threadlocal.counter;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class ThreadIsolatedCounterTest {

    private static final ThreadIsolatedCounter counter = new ThreadIsolatedCounter();

    private static final int MAX_COUNT = 5;

    private static final Runnable isolatedCountRunnable = () -> {
        while (true) {
            int count = counter.getCount();
            if (count > MAX_COUNT) {
                return;
            }
            System.out.println(Thread.currentThread().getName() + ": " + count);
            counter.increment();
        }
    };

    public static void main(String[] args) {
        AtomicInteger counterId = new AtomicInteger();
        ExecutorService service
                = Executors.newFixedThreadPool(10, r -> new Thread(r, "Counter" + counterId.getAndIncrement()));
        try (ThreadIsolatedCounter closeCounter = counter) {
            for (int i = 0 ; i < 5 ; i ++ ) {
                service.submit(isolatedCountRunnable);
            }
        }
        service.shutdown();
    }

}
