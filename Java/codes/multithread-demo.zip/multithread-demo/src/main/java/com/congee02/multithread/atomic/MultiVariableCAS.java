package com.congee02.multithread.atomic;

import java.util.concurrent.atomic.AtomicReference;

public class MultiVariableCAS {
    private static class Data {
        private int value1;
        private int value2;

        public Data(int value1, int value2) {
            this.value1 = value1;
            this.value2 = value2;
        }

        public int getValue1() {
            return value1;
        }

        public int getValue2() {
            return value2;
        }
    }

    public static void main(String[] args) {
        Data initialData = new Data(10, 20);
        AtomicReference<Data> atomicData = new AtomicReference<>(initialData);

        // Perform atomic updates using CAS
        Data newData = new Data(30, 40);
        atomicData.compareAndSet(initialData, newData);

        // Access the updated values atomically
        Data updatedData = atomicData.get();
        System.out.println("Value1: " + updatedData.getValue1());
        System.out.println("Value2: " + updatedData.getValue2());
    }
}
