package com.congee02.multithread.ordered;

public final class NaiveSynchronizedLazyLoadSingleton {

    private NaiveSynchronizedLazyLoadSingleton() {}

    private static volatile NaiveSynchronizedLazyLoadSingleton instance;

    public synchronized static NaiveSynchronizedLazyLoadSingleton getInstance() {
        if (instance == null) {
            instance = new NaiveSynchronizedLazyLoadSingleton();
        }
        return instance;
    }

}
