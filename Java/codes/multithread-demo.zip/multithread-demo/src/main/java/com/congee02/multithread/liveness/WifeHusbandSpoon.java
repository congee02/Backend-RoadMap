package com.congee02.multithread.liveness;

public class WifeHusbandSpoon {

    private static class Spoon {
        private Diner owner;

        public Spoon(Diner owner) {
            this.owner = owner;
        }

        public Diner getOwner() {
            return owner;
        }

        public synchronized void setOwner(Diner owner) {
            this.owner = owner;
        }

        public synchronized void use() {
            System.out.println(owner.name + " is using the spoon.");
        }
    }

    private static class Diner {
        private boolean isHungry;
        private String name;

        public Diner(String name) {
            this.name = name;
            this.isHungry = true;
        }

        public void eatWith(Diner spouse, Spoon spoon) {

            try {
                while (isHungry) {
                    if (spoon.getOwner() != this) {
                        Thread.sleep(1000);
                        continue;
                    }
                    if (spouse.isHungry) {
                        System.out.println(this.name + ": " + "You eat first, darling.");
                        spoon.setOwner(spouse);
                        continue;
                    }
                    spoon.use();
                    this.isHungry = false;
                    System.out.println(name + ": " + "I'm full.");
                    spoon.setOwner(spouse);
                }

            } catch (InterruptedException ignored) {
                // do nothing
            }

        }
    }

    public static void main(String[] args) {
        Diner husband = new Diner("Husband");
        Diner wife = new Diner("Wife");
        Spoon spoon = new Spoon(wife);

        new Thread(() -> husband.eatWith(wife, spoon)).start();
        new Thread(() -> wife.eatWith(husband, spoon)).start();

    }

}
