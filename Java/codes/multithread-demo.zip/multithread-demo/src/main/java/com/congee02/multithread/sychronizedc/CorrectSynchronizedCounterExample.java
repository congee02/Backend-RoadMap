package com.congee02.multithread.sychronizedc;

import java.util.TreeMap;

public class CorrectSynchronizedCounterExample {

    private static class CorrectSynchronizedCounter {

        private Integer count = 0;
        private final Object lock = new Object();

        public void increment() {
            synchronized (lock) {
                count ++;
            }
        }

        public Integer getCount() {
            synchronized (lock) {
                return count;
            }
        }

    }

    private final static CorrectSynchronizedCounter counter = new CorrectSynchronizedCounter();
    private final static Runnable incrementRunnable = () -> {
        for (int i = 0 ; i < 100 ; i ++ ) {
            counter.increment();
        }
    };
    private final static Runnable getCountRunnable = () -> {
        for (int i = 0 ; i < 100 ; i ++ ) {
            System.out.println(counter.getCount());
        }
    };

    public static void main(String[] args) {
        Thread incrementThread = new Thread(incrementRunnable, "incrementThread");
        Thread getCountThread = new Thread(getCountRunnable, "getCountThread");
        incrementThread.start();
        getCountThread.start();
    }

}
