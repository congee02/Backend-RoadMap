package com.congee02.multithread.semaphore;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

/**
 * Semaphore 实现停车场提示牌功能
 */
public class ParkingLotSign {

    private final static Semaphore SEMAPHORE = new Semaphore(10, true);

    private static final Runnable PARK_RUNNABLE = () -> {
        String name = Thread.currentThread().getName();
        System.out.println(name + ": 来到停车场");
        System.out.println(name + ": 目前有 " + SEMAPHORE.availablePermits() + " 可用的停车位");
        try {
            boolean success = SEMAPHORE.tryAcquire();
            if (! success) {
                System.out.println(name + ": 车位已满，正在等待...");
                SEMAPHORE.acquire();
            }
            System.out.println(name + ": 成功停车");
            Thread.sleep(new Random().nextInt(10_000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            SEMAPHORE.release();
            System.out.println(name + ": 驶出停车场");
        }
    };

    private final static CarThreadFactory FACTORY = new CarThreadFactory();
    private final static int CAR_NUM = 100;

    public static void main(String[] args) {
        ExecutorService service = Executors.newFixedThreadPool(CAR_NUM, FACTORY);
        for (int i = 0 ; i < CAR_NUM ; i ++ ) {
            service.submit(PARK_RUNNABLE);
        }
        service.shutdown();
    }

}
