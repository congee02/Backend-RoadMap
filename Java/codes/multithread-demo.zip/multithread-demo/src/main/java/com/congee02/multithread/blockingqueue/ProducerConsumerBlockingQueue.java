package com.congee02.multithread.blockingqueue;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ProducerConsumerBlockingQueue {

    // 缓冲区大小
    private static final int BUFFER_SIZE = 3;
    // 产品数量
    private static final int PRODUCT_NUM = 10;

    // 缓冲区
    private static final BlockingQueue<String> BUFFER = new ArrayBlockingQueue<>(BUFFER_SIZE);

    private static final String BUFFER_PRODUCT_PREFIX = "product-";

    private static final Runnable producerRunnable = () -> {
        try {
            for (int i = 0 ; i < PRODUCT_NUM ; i ++ ) {
                Thread.sleep(1);
                String currentProduct = BUFFER_PRODUCT_PREFIX + i;
                // 尝试添加产品到缓冲区
                boolean notFull = BUFFER.offer(currentProduct);
                // 若失败，则阻塞等待缓冲区不满，即消费者消费后，然后添加产品。
                if (! notFull) {
                    System.out.println("队列已满，阻塞等待队列有空位");
                    BUFFER.put(currentProduct);
                }
                System.out.println("产品 " + currentProduct + " 已经放入缓冲区中");
            }
        } catch (InterruptedException e) {
            System.err.println(e.getMessage());
        }
        System.out.println("生产者完成");
    };

    private static final Runnable consumerRunnable = () -> {
        try {
            for (int i = 0 ; i < PRODUCT_NUM ; i ++ ) {
                Thread.sleep(1);
                // 尝试取出缓冲区队头的元素
                String product = BUFFER.poll();

                boolean notEmpty = product != null;
                // 若失败，则阻塞等待缓冲区为空，等待缓冲区不空，即生产者消费后，然后消费产品
                if (! notEmpty) {
                    product = BUFFER.take();
                    System.out.println("队列已空，阻塞等待队列有产品");
                }
                System.out.println("消费者消费 " + product + "; 是否有");
            }
        } catch (InterruptedException e) {
            System.err.println(e.getMessage());
        }
        System.out.println("消费者完成");
    };

    public static void main(String[] args) {
        Thread producer = new Thread(producerRunnable, "producer");
        Thread consumer = new Thread(consumerRunnable, "consumer");
        producer.start();
        consumer.start();
    }

}
