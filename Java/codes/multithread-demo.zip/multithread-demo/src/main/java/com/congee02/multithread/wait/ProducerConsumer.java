package com.congee02.multithread.wait;


public class ProducerConsumer {

    // 锁
    private static final Object lock = new Object();

    // 生产者逻辑
    private static Runnable produce = () -> {
        // 尝试获取锁
        synchronized (lock) {
            System.out.println("Producer: Producing data...");
            try {
                // 生产者已经生产数据，等待消费者消费。
                // 暂时释放锁，等待消费者使用 lock.notify() 唤醒
                lock.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Producer: Resumed");
        }
    };

    // 消费者逻辑
    private static Runnable consume = () -> {
        // 尝试获取锁。
        // 若生产者还在生产，即生产者还持有锁，则等待生产者生产数据然后暂时释放锁
        synchronized (lock) {
            System.out.println("Consumer: Waiting for data...");
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            // 告知生产者可以重新获取锁并继续运行
            lock.notify();
        }
    };

    public static void main(String[] args) {
        Thread producer = new Thread(produce);
        Thread consumer = new Thread(consume);

        producer.start();
        consumer.start();

        try {
            producer.join();
            consumer.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
