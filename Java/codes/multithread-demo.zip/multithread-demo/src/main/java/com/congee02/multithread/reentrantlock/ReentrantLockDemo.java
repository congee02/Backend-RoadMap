package com.congee02.multithread.reentrantlock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockDemo {

    private final static ReentrantLock lock = new ReentrantLock();

    private final static Runnable r1 = () -> {
        lock.lock();
        try {
            System.out.println(Thread.currentThread().getName() + ": Inside critical section");
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    };

    private final static Runnable r2 = () -> {
        lock.lock();
        try {
            System.out.println(Thread.currentThread().getName() + ": Inside critical section");
        } finally {
            lock.unlock();
        }
    };

    public static void main(String[] args) {
        final Thread t1 = new Thread(r1, "t1");
        final Thread t2 = new Thread(r2, "t2");
        t1.start();
        t2.start();
    }

}
