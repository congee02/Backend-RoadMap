package com.congee02.multithread.priority;

public class ThreadPriorityGet {

    public static void main(String[] args) {
        new Thread(() -> {
            Thread currentThread = Thread.currentThread();
            System.out.println("Priority level of " + currentThread.getName() + " is " + currentThread.getPriority());
        }, "Default-Priority-Thread").start();
    }

}
