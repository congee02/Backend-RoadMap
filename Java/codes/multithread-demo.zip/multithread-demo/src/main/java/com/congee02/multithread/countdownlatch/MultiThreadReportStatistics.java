package com.congee02.multithread.countdownlatch;

import com.congee02.multithread.utils.SimpleProfileUtils;

import java.util.Map;
import java.util.concurrent.*;

public class MultiThreadReportStatistics implements Runnable {

    private final static Map<String, Integer> AGGREGATED = new ConcurrentHashMap<>();

    private final static int INDICATE_LOOKUP_NUM = 4;
    private final static long MONITOR_SECONDS = 3L;

    private final static CountDownLatch latch = new CountDownLatch(INDICATE_LOOKUP_NUM);

    // 模拟耗时的查询操作
    private static void monitorWork() throws InterruptedException {
        TimeUnit.SECONDS.sleep(MONITOR_SECONDS);
    }

    private static final Runnable countNewUser = () -> {
        try {
            System.out.println("正在查询新增用户数量");
            monitorWork();
            AGGREGATED.put("userNumber", 1);
            System.out.println("查询新增用户完毕");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            latch.countDown();
        }
    };

    private static final Runnable countOrder = () -> {
        try {
            System.out.println("正在查询订单数量");
            monitorWork();
            AGGREGATED.put("countOrder", 2);
            System.out.println("查询订单数量完毕");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            latch.countDown();
        }
    };

    private static final Runnable countGoods = () -> {
        try {
            System.out.println("正在查询商品数量");
            monitorWork();
            AGGREGATED.put("countGoods", 3);
            System.out.println("商品数量销售完毕");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            latch.countDown();
        }
    };

    private static final Runnable countSales = () -> {
        try {
            System.out.println("正在查询销售总额");
            monitorWork();
            AGGREGATED.put("countSales", 4);
            System.out.println("查询销售总额完毕");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            latch.countDown();
        }
    };

    @Override
    public void run() {

        ExecutorService service = Executors.newFixedThreadPool(4);

        service.submit(countNewUser);
        service.submit(countOrder);
        service.submit(countGoods);
        service.submit(countSales);

        try {
            latch.await();
            System.out.println("统计指标全部完成");
            System.out.println("统计结果: " + AGGREGATED);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        service.shutdown();

    }

    public static void main(String[] args) {
        System.out.println("任务耗时：" + SimpleProfileUtils.millisProfile(new MultiThreadReportStatistics()) / 1000.0 + "秒");
    }
}
