package com.congee02.multithread.practice.producerconsumer;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ProducerConsumerCondition {

    private static final Lock lock = new ReentrantLock(true);

    private static final Condition notEmpty = lock.newCondition();
    private static final Condition notFull  = lock.newCondition();

    private static final int SHARED_BUFFER_SIZE = 10;
    private static final List<String> SHARED_BUFFER = new LinkedList<>();

    private static final int PRODUCT_NUM_PER_PRODUCER = 10;
    private static final String PRODUCT_PREFIX = "product-";
    private static volatile AtomicInteger productId = new AtomicInteger(0);

    private static final int PRODUCER_NUM = 5;
    private static final int CONSUMER_NUM = PRODUCER_NUM;

    private static final String PRODUCER_PREFIX = "PRODUCER-";
    private static final String CONSUMER_PREFIX = "CONSUMER-";

    private static String prefixId(String prefix, int id) {
        return prefix + id;
    }

    private static class PrefixThreadFactory implements ThreadFactory {

        private final String prefix;
        private int id;

        private PrefixThreadFactory(String prefix) {
            this.prefix = prefix;
            this.id = 0;
        }

        @Override
        public Thread newThread(Runnable r) {
            return new Thread(r, prefixId(this.prefix, this.id ++));
        }
    }

    private static final Runnable producerRunnable = () -> {
        String name = Thread.currentThread().getName();
        lock.lock();
        try {
            for (int i = 0 ; i < PRODUCT_NUM_PER_PRODUCER ; i ++ ) {
                String product = prefixId(PRODUCT_PREFIX, productId.getAndIncrement());
                System.out.println(name + ": produces " + product);
                System.out.println(name + ": trying to put " + product + " into shared buffer");
                boolean success = SHARED_BUFFER.size() < SHARED_BUFFER_SIZE;
                if (! success) {
                    System.out.println(name + ": the shared buffer is full, waiting...");
                    while (SHARED_BUFFER.size() >= SHARED_BUFFER_SIZE) {
                        notEmpty.signal();
                        notFull.await();
                    }
                }
                SHARED_BUFFER.add(product);
                notEmpty.signal();
                System.out.println(name + ": has put " + product + " into shared buffer");
            }
        } catch (InterruptedException e) {
            System.out.println("Monitor handle " + e);
        } finally {
            lock.unlock();
        }
    };

    private final static Runnable consumerRunnable = () -> {
        String name = Thread.currentThread().getName();
        lock.lock();
        try {
            for (int i = 0 ; i < PRODUCT_NUM_PER_PRODUCER ; i ++ ) {
                System.out.println(name + ": trying to take a product from shared buffer");
                boolean success = SHARED_BUFFER.size() > 0;
                if (! success) {
                    System.out.println(name + ": the shared buffer is empty, waiting...");
                    while (SHARED_BUFFER.size() <= 0) {
                        notFull.signal();
                        notEmpty.await();
                    }
                }
                String product = SHARED_BUFFER.remove(0);
                notFull.signal();
                System.out.println(name + ": has taken " + product + " from shared buffer");
            }
        } catch (InterruptedException e) {
            System.out.println("Monitor handle " + e);
        } finally {
            lock.unlock();
        }
    };

    public static void main(String[] args) {
        ExecutorService producerPool =
                Executors.newFixedThreadPool(PRODUCER_NUM, new PrefixThreadFactory(PRODUCER_PREFIX));
        for (int i = 0 ; i < PRODUCER_NUM ; i ++ ) {
            producerPool.execute(producerRunnable);
        }
        ExecutorService consumerPool =
                Executors.newFixedThreadPool(CONSUMER_NUM, new PrefixThreadFactory(CONSUMER_PREFIX));
        for (int i = 0 ; i < CONSUMER_NUM ; i ++ ) {
            consumerPool.execute(consumerRunnable);
        }
        producerPool.shutdown();
        consumerPool.shutdown();
    }

}
