package com.congee02.multithread.group;

public class MainThreadGroupInsight {

    public static void main(String[] args) {
        // 获取当前线程的线程组
        ThreadGroup mainThreadGroup = Thread.currentThread().getThreadGroup();

        // 获取当前线程的线程组的父线程组
        ThreadGroup mainThreadGroupParent = mainThreadGroup.getParent();

        // 当前线程为 main 线程，隶属于 main 线程组
        System.out.println("mainThreadGroup: " + mainThreadGroup);

        // main 线程组的父线程组为 system
        System.out.println("mainThreadGroupParent: " + mainThreadGroupParent);
    }

}
