package com.congee02.multithread.group;

public class ThreadGroupCreate {

    private final static Runnable createThreadGroup = () -> {
        // 若未指定，默认的父线程组为当前线程的线程组
        ThreadGroup subThreadGroup1 = new ThreadGroup("subThreadGroup1");
        // 指定父线程组为 subThreadGroup1
        ThreadGroup subThreadGroup2 = new ThreadGroup(subThreadGroup1, "subThreadGroup2");

        // Parent of subThreadGroup1: currentThreadGroup
        System.out.println("Parent of subThreadGroup1: " + subThreadGroup1.getParent().getName());
        // Parent of subThreadGroup2: subThreadGroup1
        System.out.println("Parent of subThreadGroup2: " + subThreadGroup2.getParent().getName());
    };

    public static void main(String[] args) {

        ThreadGroup currentThreadGroup = new ThreadGroup("currentThreadGroup");
        Thread creteThreadGroupThread = new Thread(currentThreadGroup, createThreadGroup);
        creteThreadGroupThread.start();

    }

}
