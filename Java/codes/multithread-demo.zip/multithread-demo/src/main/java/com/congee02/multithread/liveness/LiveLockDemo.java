package com.congee02.multithread.liveness;

import java.util.concurrent.TimeUnit;

public class LiveLockDemo {

    private static boolean flag = true;

    private static class YieldRunnable implements Runnable {
        private boolean whileConditionReverse;

        public YieldRunnable(boolean whileConditionReverse) {
            this.whileConditionReverse = whileConditionReverse;
        }

        @Override
        public void run() {
            String name = Thread.currentThread().getName();
            while (whileConditionReverse != flag) {
                System.out.println(name + " is waiting.");
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println(name + " finished.");
        }
    }

    private final static Thread xYieldThread = new Thread(new YieldRunnable(true), "X");
    private final static Thread yYieldThread = new Thread(new YieldRunnable(false), "Y");

    public static void main(String[] args) throws InterruptedException {

        xYieldThread.start();
        yYieldThread.start();

        TimeUnit.SECONDS.sleep(1);

        flag = !flag;

        xYieldThread.join();
        yYieldThread.join();
    }

}
