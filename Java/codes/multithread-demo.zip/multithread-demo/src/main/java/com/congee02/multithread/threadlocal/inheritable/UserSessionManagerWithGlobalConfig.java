package com.congee02.multithread.threadlocal.inheritable;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class UserSessionManagerWithGlobalConfig {

    private static final ThreadLocal<Map<String, Object>> threadLocalSession = ThreadLocal.withInitial(HashMap::new);

    private static class GlobalSessionConfiguration extends InheritableThreadLocal<Map<String, String>> {
        @Override
        protected Map<String, String> initialValue() {
            checkMainThread();
            return new HashMap<>();
        }

        @Override
        public void set(Map<String, String> value) {
            checkMainThread();
            super.set(value);
        }

        private static void checkMainThread() {
            if (! Thread.currentThread().getName().equals("main")) {
                throw new RuntimeException("The global configuration must be write in the main thread.");
            }
        }

        public String putConfigEntry(String key, String value) {
            checkMainThread();
            Map<String, String> map = get();
            String oldConfigValue = map.put(key, value);
            set(map);
            return oldConfigValue;
        }

        public String removeConfigEntry(String key) {
            checkMainThread();
            Map<String, String> map = get();
            String removedConfigValue = map.remove(key);
            set(map);
            return removedConfigValue;
        }

        public String getConfig(String key) {
            return get().get(key);
        }

    }
    private static final GlobalSessionConfiguration globalSessionConfiguration = new GlobalSessionConfiguration();

    public static Map<String, Object> notNullCheckedCurrentSessionMap() {
        return Objects.requireNonNull(threadLocalSession.get());
    }

    public static void setSessionAttribute(String key, Object value) {
        notNullCheckedCurrentSessionMap().put(key, value);
    }

    public static Object getSessionAttribute(String key) {
        return notNullCheckedCurrentSessionMap().get(key);
    }

    public static void clearSession() {
        Map<String, Object> currentSessionMap = notNullCheckedCurrentSessionMap();
        try {
            currentSessionMap.clear();      // help GC
        } finally {
            threadLocalSession.remove();    // avoid resource leaking
        }
    }

    public static void main(String[] args) throws InterruptedException {

        globalSessionConfiguration.putConfigEntry("token", "xyz");
        globalSessionConfiguration.putConfigEntry("secret", "wuz");

        System.out.println("From InheritableThreadLocal " + Thread.currentThread().getName() + ": " + globalSessionConfiguration.getConfig("token"));

        setSessionAttribute("Greeting", "Hello");
        System.out.println("From ThreadLocal " + Thread.currentThread().getName() + ": " + getSessionAttribute("Greeting"));
        Thread thread = new Thread(() -> {
            System.out.println("From ThreadLocal " + Thread.currentThread().getName() + ": " + getSessionAttribute("Greeting"));
            System.out.println("From InheritableThreadLocal " + Thread.currentThread().getName() + ": " + globalSessionConfiguration.getConfig("token"));
        });
        thread.start();
        thread.join();
        clearSession();
        globalSessionConfiguration.remove();
    }

}
