package com.congee02.multithread.reentrantlock;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockAvoidDeadLock {

    private static Lock lockA = new ReentrantLock() {
        private static final long serialVersionUID = 2908450255897378151L;

        @Override
        public String toString() {
            return "lockA";
        }
    };
    private static Lock lockB = new ReentrantLock() {
        private static final long serialVersionUID = -9139042317565343434L;

        @Override
        public String toString() {
            return "lockB";
        }
    };

    private static void acquireLockAndWork(Lock firstLock, Lock secondLock) {
        firstLock.lock();
        System.out.println(Thread.currentThread().getName() + " acquired " + firstLock);

        try {
            Thread.sleep(1000);

            secondLock.lock();
            System.out.println(Thread.currentThread().getName() + " acquired " + secondLock);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            firstLock.unlock();
            secondLock.unlock();
        }
    }

    public static void main(String[] args) {
        final Thread x = new Thread(() -> acquireLockAndWork(lockA, lockB), "X");
        final Thread y = new Thread(() -> acquireLockAndWork(lockA, lockB), "Y");

        x.start();
        y.start();
    }

}
