package com.congee02.multithread.atomic;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;

public class BatchCAS {

    private static class BatchCASValues {

        private final Object[] casValues;

        public BatchCASValues(Object... casValues) {
            this.casValues = casValues;
        }

        // 创建并返回一个深拷贝的 BatchCASValues 实例
        public BatchCASValues deepClone() {
            return new BatchCASValues(Arrays.copyOf(casValues, casValues.length));
        }

        // 直接设置指定索引处的值，无CAS保护，仅为演示用途
        private void unsafeSet(int index, Object value) {
            casValues[index] = value;
        }

        @Override
        public String toString() {
            return "BatchCASValues{" +
                    "casValues=" + Arrays.toString(casValues) +
                    '}';
        }
    }

    private final static AtomicReference<BatchCASValues> ATOMIC_REFERENCE = new AtomicReference<>();

    public static void main(String[] args) {
        // 创建一个初始的 BatchCASValues 实例并设置到 ATOMIC_REFERENCE 中
        BatchCASValues referenceHoldValue = new BatchCASValues(1, 2, 3, "Hello");
        ATOMIC_REFERENCE.set(referenceHoldValue);

        BatchCASValues expectedValue = referenceHoldValue.deepClone();
        expectedValue.unsafeSet(0, 98.2);

        BatchCASValues newValue = referenceHoldValue.deepClone();
        newValue.unsafeSet(1, 100);

        // 创建一个新线程，在一段时间后将 ATOMIC_REFERENCE 更新为 expectedValue
        new Thread(() -> {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            ATOMIC_REFERENCE.compareAndSet(referenceHoldValue, expectedValue);
        }).start();

        // 在主线程中，循环尝试将 ATOMIC_REFERENCE 更新为 newValue
        while (! ATOMIC_REFERENCE.compareAndSet(expectedValue, newValue)) {
            // 循环直到更新成功
        }

        // 输出最终的 ATOMIC_REFERENCE 值
        System.out.println(ATOMIC_REFERENCE.get());

    }

}
