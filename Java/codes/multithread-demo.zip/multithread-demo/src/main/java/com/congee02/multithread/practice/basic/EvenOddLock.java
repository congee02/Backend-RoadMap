package com.congee02.multithread.practice.basic;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class EvenOddLock {

    private static final int MAX_COUNT = 100;
    private static int count = 0;

    private final static Lock lock = new ReentrantLock();

    public static final Runnable oddRunnable = () -> {
        while (count <= MAX_COUNT) {
            lock.lock();
            String name = Thread.currentThread().getName();
            try {
                if ((count & 1) == 1) {
                    System.out.println(name + ": odd, " + count ++);
                }
            } finally {
                lock.unlock();
            }
        }
    };

    private static final Runnable evenRunnable = () -> {
        while (count <= MAX_COUNT) {
            lock.lock();
            String name = Thread.currentThread().getName();
            try {
                if ((count & 1) == 0) {
                    System.out.println(name + ": even, " + count ++);
                }
            } finally {
                lock.unlock();
            }
        }
    };

    public static void main(String[] args) {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        pool.execute(oddRunnable);
        pool.execute(evenRunnable);
        pool.shutdown();
    }

}
