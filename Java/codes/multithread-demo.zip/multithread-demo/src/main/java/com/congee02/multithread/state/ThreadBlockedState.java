package com.congee02.multithread.state;

public class ThreadBlockedState {

    // 锁 同步区
    private final static Object resource = new Object();
    private static final Runnable getLockAndRun = () -> {
        // 尝试得到锁。若锁被占用，等待锁被释放，在此期间线程等待资源，状态为 BLOCK
        synchronized (resource) {
            System.out.println(Thread.currentThread().getName() + ": Holding the lock...");
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName() + ": Release the lock...");
        }

    };

    public static void main(String[] args) throws InterruptedException {

        Thread t1 = new Thread(getLockAndRun, "Thread1");
        t1.start();
        Thread t2 = new Thread(getLockAndRun, "Thread2");
        t2.start();
        while (t2.getState() != Thread.State.TERMINATED) {
            Thread.sleep(1000); // 增加适当的延迟
            System.out.println("Thread2 state: " + t2.getState());
        }
        System.out.println(t2.getState());
    }

}
