package com.congee02.multithread;

import java.util.List;

public final class ThreadUtils {

    private ThreadUtils() {}

    public static void startThreads(List<Thread> threads) {
        threads.forEach(Thread::start);
    }

    public static void runThreads(List<Thread> threads) {
        threads.forEach(Thread::run);
    }

}
