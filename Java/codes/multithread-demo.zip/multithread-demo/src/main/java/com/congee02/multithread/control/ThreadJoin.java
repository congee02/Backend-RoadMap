package com.congee02.multithread.control;

import java.util.Random;

public class ThreadJoin {

    public static void main(String[] args) {
        Random random = new Random();
        Runnable count = () -> {
            for (int i = 0; i < 5; i++) {
                try {
                    Thread.sleep(random.nextInt(10));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(Thread.currentThread().getName() + " : " + i);
            }
        };

        Thread joinThread = new Thread(count, "Join Thread");
        joinThread.start();
        try {
            joinThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("===== Join Thread End =====");

        Thread t1 = new Thread(count, "Normal Thread " + 1);
        Thread t2 = new Thread(count, "Normal Thread " + 2);
        Thread t3 = new Thread(count, "Normal Thread " + 3);

        t1.start();
        t2.start();
        t3.start();
    }

}
