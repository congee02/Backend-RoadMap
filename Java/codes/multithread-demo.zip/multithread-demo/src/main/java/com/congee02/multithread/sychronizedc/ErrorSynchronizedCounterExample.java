package com.congee02.multithread.sychronizedc;

public class ErrorSynchronizedCounterExample {

    private static class ErrorSynchronizedCounter {
        private volatile Integer count = 0;

        public void increment() {
            synchronized (count) {
                // Integer 对象是不可变的，执行 count ++ 时，
                // 实际上创建了一个新的 Integer 对象并赋值给 count，
                // 导致每个进程进入 synchronized (count) 时获取的其实是不同的锁对象
                count ++;
            }
        }

        public int getCount() {
            synchronized (count) {
                return count;
            }
        }
    }

}
