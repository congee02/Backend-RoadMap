package com.congee02.multithread.practice.atomiccounter;

import java.util.concurrent.atomic.AtomicInteger;

public class AtomicCounter {

    private final AtomicInteger value;

    public AtomicCounter() {
        this.value = new AtomicInteger(0);
    }

    public void increment() {
        value.incrementAndGet();
    }

    public int get() {
        return value.get();
    }
}
