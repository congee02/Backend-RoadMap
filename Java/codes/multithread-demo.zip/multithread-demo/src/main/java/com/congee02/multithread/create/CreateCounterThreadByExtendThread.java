package com.congee02.multithread.create;

import com.congee02.multithread.ThreadUtils;

import java.util.List;

public class CreateCounterThreadByExtendThread {

private static class CounterExtendThread extends Thread {

    public CounterExtendThread(String name) {
        super(name);
    }

    @Override
    public void run() {
        for (int i = 0 ; i < 10; i ++ ) {
            System.out.println(Thread.currentThread().getName() + " : " + i);
        }
    }

}

    private static List<Thread> threads() {
        CounterExtendThread firstCounter =
                new CounterExtendThread("firstCounter");
        CounterExtendThread secondCounter =
                new CounterExtendThread("secondCounter");
        CounterExtendThread thirdCounter =
                new CounterExtendThread("thirdCounter");

        return List.of(
                firstCounter,
                secondCounter,
                thirdCounter
        );
    }


    public static void main(String[] args) {
        System.out.println("===== Thread::run =====");
        ThreadUtils.runThreads(threads());
        System.out.println("===== Thread::start =====");
        ThreadUtils.startThreads(threads());
    }

}
