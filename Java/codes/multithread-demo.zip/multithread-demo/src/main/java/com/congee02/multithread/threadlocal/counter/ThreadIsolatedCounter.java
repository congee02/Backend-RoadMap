package com.congee02.multithread.threadlocal.counter;

import java.io.Closeable;

public class ThreadIsolatedCounter implements Closeable {

    private final static ThreadLocal<Integer> countThreadLocal = ThreadLocal.withInitial(() -> 0);

    public void increment() {
        countThreadLocal.set(countThreadLocal.get() + 1);
    }

    public int getCount() {
        return countThreadLocal.get();
    }

    @Override
    public void close() {
        countThreadLocal.remove();
    }

}
