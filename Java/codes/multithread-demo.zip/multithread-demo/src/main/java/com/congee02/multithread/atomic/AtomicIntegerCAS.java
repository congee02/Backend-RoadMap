package com.congee02.multithread.atomic;

import java.util.concurrent.atomic.AtomicInteger;

public class AtomicIntegerCAS {

    private static final AtomicInteger num = new AtomicInteger(10);

    private static boolean cas(int expected, int newValue) {
        return num.compareAndSet(expected, newValue);
    }

    public static void main(String[] args) {
        int expected, newValue;

        expected = 10;
        newValue = 20;
        for (;;) {
            if (cas(expected, newValue)) {
                System.out.println("expected: " + expected + "; newValue: " + newValue);
                break;
            }
        }

        Thread thread = new Thread(() -> {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            num.compareAndSet(20, 15);
        });
        thread.start();


        expected = 15;
        newValue = 30;
        for (;;) {
            if (cas(expected, newValue)) {
                System.out.println("expected: " + expected + "; newValue: " + newValue);
                break;
            }
        }
    }

}
