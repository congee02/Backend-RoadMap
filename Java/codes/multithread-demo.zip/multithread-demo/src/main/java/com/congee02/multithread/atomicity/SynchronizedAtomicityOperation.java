package com.congee02.multithread.atomicity;

import java.util.Random;

public class SynchronizedAtomicityOperation {

    /**
     * 原子操作的计数器
     */
    private static class AtomicIncrementCounter {

        // 创建一个锁对象
        private final Object lock = new Object();

        private int count = 0;

        public void increment() {
            synchronized (lock) {
                count ++;
                System.out.println("Thread " + Thread.currentThread().getName() + " executed increment().");
            }
        }

        public int getCount() {
            return count;
        }
    }

    private static final Random random = new Random();

    private static final AtomicIncrementCounter counter = new AtomicIncrementCounter();
    private static final Runnable incrementRunnable = () -> {
        for (int i = 0; i < 100 ; i ++ ) {
            try {
                Thread.sleep(random.nextInt(10));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            counter.increment();
        }
    };

    public static void main(String[] args) {

        Thread firstThread = new Thread(incrementRunnable, "firstThread");
        Thread secondThread = new Thread(incrementRunnable, "secondThread");

        firstThread.start();
        secondThread.start();

        // 等待线程执行完成后打印结果
        try {
            firstThread.join();
            secondThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(counter.getCount());
    }

}
