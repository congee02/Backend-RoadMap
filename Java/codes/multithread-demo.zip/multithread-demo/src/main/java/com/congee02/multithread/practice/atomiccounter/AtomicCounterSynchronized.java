package com.congee02.multithread.practice.atomiccounter;

public class AtomicCounterSynchronized {

    private int value;

    public AtomicCounterSynchronized() {
        this.value = 0;
    }

    public synchronized void increment() {
        this.value ++;
    }

    public int getValue() {
        return value;
    }

}
