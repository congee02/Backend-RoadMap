package com.congee02.multithread.aqs;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;

public class NonReentrantLockTest {

    private static int accumulation = 0;

    private static final Lock lock = new NonReentrantLock();

    private static final Runnable accumulationRunnable = () -> {
        lock.lock();
        try {
            for (int i = 0 ; i < 1000000 ; i ++ ) {
                accumulation ++;
            }
        } finally {
            lock.unlock();
        }
    };

    public static void main(String[] args) {
        final ThreadPoolExecutor pool =
                new ThreadPoolExecutor(5, 5, 1000, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(10));
        for (int i = 0 ; i < 5 ; i ++ ) {
            pool.execute(accumulationRunnable);
        }
        pool.shutdown();
        while (! pool.isTerminated()) {}
        System.out.println(accumulation);
    }

}
