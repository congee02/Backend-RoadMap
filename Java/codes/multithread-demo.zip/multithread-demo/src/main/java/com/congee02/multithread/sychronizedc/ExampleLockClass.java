package com.congee02.multithread.sychronizedc;

public final class ExampleLockClass {

    private ExampleLockClass() {}

    public static synchronized void foo() {
        System.out.println("Foo invoked.");
    }

}
