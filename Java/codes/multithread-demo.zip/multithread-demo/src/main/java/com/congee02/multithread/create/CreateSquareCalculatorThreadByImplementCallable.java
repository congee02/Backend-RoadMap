package com.congee02.multithread.create;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

public class CreateSquareCalculatorThreadByImplementCallable {

    private static class SquareCalculator implements Callable<Integer> {

        private int number;

        public SquareCalculator(int number) {
            this.number = number;
        }

        @Override
        public Integer call() throws Exception {
            Thread.sleep(1000L);
            return number * number;
        }
    }

    public static void main(String[] args) {
        FutureTask<Integer> task = new FutureTask<>(new SquareCalculator(20));
        new Thread(task).start();
        try {
            Integer result = task.get();
            System.out.println(result);
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

}
