package com.congee02.multithread.state;

public class ThreadNewState {

    public static void main(String[] args) {
        // 创建线程，但尚未启动 (start 方法)，此时线程处于 NEW 状态
        Thread thread = new Thread(() -> {});
        System.out.println(thread.getState());
    }

}
