package com.congee02.multithread.threadlocal.memleak;

public class ThreadLocalBestPractice {

    private static ThreadLocal<Object> objectThreadLocal = new ThreadLocal<>();

    private void putIntoThreadLocal(Object obj) {
        objectThreadLocal.set(obj);
    }

    private final Runnable putRunnable = () -> {
        objectThreadLocal.set(new Object());
        try {
            // Simulator some calculations
            System.out.println("Simulating some works.");
        } finally {
            objectThreadLocal.remove();
        }
    };

    public static void main(String[] args) {

    }

}
