package com.congee02.multithread.liveness;

import java.util.concurrent.TimeUnit;

public class StarvationDemo {

    private static final Object resource = new Object() {
        @Override
        public String toString() {
            return "resource";
        }
    };

    // 定义一个长时间持有资源的任务
    private final static Runnable holdResourceLongTimeRunnable = () -> {
        String name = Thread.currentThread().getName();
        System.out.println(name + " is trying to access the resource");
        synchronized (resource) {
            System.out.println(name + " acquired the resource.");
            try {
                // 模拟高优先级线程长时间占用资源
                TimeUnit.SECONDS.sleep(10);
            } catch (InterruptedException e) {
                System.out.println(name + " is interrupted.");
            }
            System.out.println(name + " released the resource.");
        }
    };

    private static Thread setThreadPriority(Thread thread, int priority) {
        thread.setPriority(priority);
        return thread;
    }

    public static void main(String[] args) throws InterruptedException {
        // 创建一个优先级最高的线程
        Thread highPriorityThread =
                setThreadPriority(new Thread(holdResourceLongTimeRunnable, "High-Priority-Thread"), Thread.MAX_PRIORITY);

        // 创建一个优先级最低的线程
        Thread lowPriorityThread =
                setThreadPriority(new Thread(holdResourceLongTimeRunnable, "Low-Priority-Thread"), Thread.MIN_PRIORITY);

        // 启动两个线程
        highPriorityThread.start();
        lowPriorityThread.start();

        Thread.sleep(100);

        int count = 0;
        while (lowPriorityThread.getState() == Thread.State.BLOCKED) {
            TimeUnit.SECONDS.sleep(1);
            count ++;
            if (count == 5) {
                System.err.println("Time out, thread" + lowPriorityThread + "becomes invalid.");
                lowPriorityThread.stop();
            }
        }
    }

}
