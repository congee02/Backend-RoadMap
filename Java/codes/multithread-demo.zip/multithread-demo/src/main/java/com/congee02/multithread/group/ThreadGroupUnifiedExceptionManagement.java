package com.congee02.multithread.group;

public class ThreadGroupUnifiedExceptionManagement {

    public static void main(String[] args) {
        ThreadGroup group
                = new ThreadGroup("Print-Uncaught-Exception-ThreadGroup") {
            @Override
            // 重写处理异常的方法
            public void uncaughtException(Thread t, Throwable e) {
                System.out.println(t.getName() + " throws a exception:  " + e.getMessage());
            }
        };

        Thread thread = new Thread(group, () -> {
            // 抛出一个异常
            throw new RuntimeException("This is a testing Exception.");
        }, "Throw-Exception-Thread");

        thread.start();
    }

}
