package com.congee02.multithread.utils;

public final class SimpleProfileUtils {

    private SimpleProfileUtils() {}

    public static long nanoProfile(Runnable runnable) {
        long st = System.nanoTime();
        runnable.run();
        long ed = System.nanoTime();
        return ed - st;
    }

    public static long millisProfile(Runnable runnable) {
        long st = System.currentTimeMillis();
        runnable.run();
        long ed = System.currentTimeMillis();
        return ed - st;
    }

}
