package com.congee02.multithread.utils;

public class DemonstrateEntity implements Runnable {

    private final String demonstrationName;
    private final Runnable runnable;

    private DemonstrateEntity(String demonstrationName, Runnable runnable) {
        this.demonstrationName = demonstrationName;
        this.runnable = runnable;
    }

    @Override
    public void run() {
        printDemonstrateHeader();
        runnable.run();
    }

    private void printDemonstrateHeader() {
        StringBuilder builder = new StringBuilder("----------\t");
        builder.append(demonstrationName);
        builder.append("\t----------");
        System.out.println(builder);
    }

    public static DemonstrateEntity create(String demonstrationName, Runnable runnable) {
        return new DemonstrateEntity(demonstrationName, runnable);
    }

}
