package com.congee02.multithread.reuslt;

import java.util.ArrayList;
import java.util.concurrent.*;

public class CallableGetExecuteComputationResult {

    private static final int CALLABLE_TASK_NUM = 5;

    public static void main(String[] args) {

        // 固定大小的线程池
        ExecutorService executorService = Executors.newFixedThreadPool(3);

        // 创建 FutureTask 任务
        ArrayList<FutureTask<Integer>> tasks = new ArrayList<>(CALLABLE_TASK_NUM);
        for (int i = 0 ; i < CALLABLE_TASK_NUM ; i ++ ) {
            int index = i;
            tasks.add(new FutureTask<>(() -> {
                TimeUnit.SECONDS.sleep(index);
                return (index + 1) * 100;
            }));
        }

        // 提交 FutureTask 任务到 executorService
        tasks.forEach(executorService::submit);

        // 打印任务结果
        tasks.stream().map(task -> {
            try {
                return task.get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
            return null;
        }).forEach(System.out::println);

        // 关闭线程池
        executorService.shutdown();
    }

}
