package com.congee02.multithread.condition.producerconsumer;

public class ConditionProducerConsumerQueueTest {

    private static final ConditionProducerConsumerQueue queue = new ConditionProducerConsumerQueue();

    private static final int CONSUMER_NUM = 10;
    private static final int PRODUCER_NUM = 10;

    private static int staticProductId = 0;

    private static final Runnable producerRunnable = () -> {
        while (true) {
            queue.put("Product" + staticProductId ++);
        }
    };

    private static final Runnable consumerRunnable = () -> {
        while (true) {
            queue.take();
        }
    };

    public static void main(String[] args) {
        for (int i = 0 ; i < PRODUCER_NUM ; i ++ ) {
            new Thread(producerRunnable, "Producer" + i).start();
        }
        for (int i = 0 ; i < CONSUMER_NUM ; i ++ ) {
            new Thread(consumerRunnable, "Consumer" + i).start();
        }
    }

}
