package com.congee02.multithread.control;

public class ThreadSetDaemon {

    public static void main(String[] args) {
        Thread loggerDaemon = loggerDaemon();
        loggerDaemon.start();

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    private static Thread loggerDaemon() {
        Thread thread = new Thread(logger());
        thread.setDaemon(true);
        return thread;
    }

    private static Runnable logger() {
        return () -> {
            try {
                int count = 1;
                while (true) {
                    System.out.println("Logging entry " + count ++);
                    Thread.sleep(1000);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        };
    }

}
