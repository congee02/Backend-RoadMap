package com.congee02.multithread.condition.producerconsumer;

import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 场景：实现一个消息队列，有多个线程会往该队列里面写消息，同时也会存在多个线程会从消息里面读消息，队列的容量只有10个。
 *
 * 条件：
 *
 * 队列不为满条件：队列里面消息没有满的情况下才能往队里面添加消息。
 *
 * 队列不为空条件：消费消息的时候队列里必须有消息才进行消费。
 *
 * 加锁：因为是多线程所以需要防止消息被多个线程同时消费，同时也要防止写消息的时候一个线程存的消息被其他线程覆盖，所以队列操作的时候必须加锁。
 */
public class ConditionProducerConsumerQueue {

    /**
     * 消息队列最大大小
     */
    private final int MESSAGE_QUEUE_MAX_SIZE = 10;

    /**
     * 锁
     */
    private Lock lock = new ReentrantLock(true);
    /**
     * 消息容器
     */
    private List<String> listQueue = new LinkedList<>();
    /**
     * 队列不为空
     */
    private Condition notEmpty = lock.newCondition();
    /**
     * 队列不为满
     */
    private Condition notFull = lock.newCondition();

    public void put(String message) {
        // 操作队列前加锁
        lock.lock();
        try {
            // 队列满，通知消费者，生产线程阻塞，暂时释放锁
            while (listQueue.size() >= MESSAGE_QUEUE_MAX_SIZE) {
                notEmpty.signal();
                System.out.println("队列已满, " + Thread.currentThread().getName() + " 等待");
                notFull.await();
            }

            // 队列中加入一条消息，通知消费者有新消息
            listQueue.add(message);
            System.out.println(Thread.currentThread().getName() + " 生产 : " + message);
            // 通知消费者线程
            notEmpty.signal();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public void take() {
        lock.lock();
        try {
            // 队列空，通知生产者，消费者线程阻塞，暂时释放锁
            while (listQueue.size() <= 0) {
                System.out.println("队列已空, " + Thread.currentThread().getName() + " 等待");
                notEmpty.await();
            }
            // 取队头并删去队头
            String message = listQueue.get(0);
            listQueue.remove(0);
            System.out.println(Thread.currentThread().getName() + " 消费 : " + message);
            // 通知生产者继续生产
            notFull.signal();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

}
