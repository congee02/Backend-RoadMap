package com.congee02.multithread.volatilec;

public class VolatileExample {

    /**
     * volatile 开关
     */
    private static class VolatileFlagToggle {
        private volatile boolean flag = false;

        public synchronized void toggleFlag() {
            flag = ! flag;
            System.out.println(Thread.currentThread().getName() + " : " + "Flag has been toggled.");
        }

        public void printFlag() {
            System.out.println(Thread.currentThread().getName() + " : " + "The flag is " + flag + ".");
        }
    }

    private final static VolatileFlagToggle toggle = new VolatileFlagToggle();

    /**
     * 打开开关
     */
    private static final Runnable writeRunnable = () -> {
        toggle.toggleFlag();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    };

    /**
     * 等待开关开启
     */
    private final static Runnable readRunnable = () -> {
        while (! toggle.flag);
        toggle.printFlag();
    };

    public static void main(String[] args) {

        final Thread writeThread = new Thread(writeRunnable, "writeThread");
        final Thread readThread = new Thread(readRunnable, "readThread");

        writeThread.start();
        readThread.start();


    }

}
