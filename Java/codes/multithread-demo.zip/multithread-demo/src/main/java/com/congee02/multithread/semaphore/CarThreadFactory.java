package com.congee02.multithread.semaphore;

import java.util.concurrent.ThreadFactory;

public class CarThreadFactory implements ThreadFactory {

    private final String CAR_PREFIX = "CAR-";
    private static int carId = 0;

    @Override
    public Thread newThread(Runnable r) {
        return new Thread(r, CAR_PREFIX + (carId ++));
    }
}
