package com.congee02.multithread.liveness;

public class DeadLockDemo {

    private final static Object resourceA = new Object() {
        @Override
        public String toString() {
            return "resource A";
        }
    };
    private final static Object resourceB = new Object() {
        @Override
        public String toString() {
            return "resource B";
        }
    };

    private static class TwoResourceRunnable implements Runnable {

        private final Object firstResource;
        private final Object secondResource;

        public TwoResourceRunnable(Object firstResource, Object secondResource) {
            this.firstResource = firstResource;
            this.secondResource = secondResource;
        }

        @Override
        public void run() {
            String currentThreadName = Thread.currentThread().getName();
            synchronized (firstResource) {
                System.out.println(currentThreadName + ": holding " + firstResource);
                System.out.println(currentThreadName + ": requesting " + secondResource);
                synchronized (secondResource) {
                    System.out.println(currentThreadName + ": get " + secondResource);
                }
                System.out.println(currentThreadName + " finished.");
            }
        }

    }

    public static void main(String[] args) {

        Thread x = new Thread(new TwoResourceRunnable(resourceB, resourceA), "X");
        Thread y = new Thread(new TwoResourceRunnable(resourceA, resourceB), "Y");

        x.start();
        y.start();
    }


}
