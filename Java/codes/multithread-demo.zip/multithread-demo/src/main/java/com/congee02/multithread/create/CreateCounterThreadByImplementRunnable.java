package com.congee02.multithread.create;

import com.congee02.multithread.ThreadUtils;

import java.util.List;

public class CreateCounterThreadByImplementRunnable {

    private static class CounterImplementRunnable implements Runnable {

        @Override
        public void run() {
            for (int i = 0 ; i <  10 ; i ++ ) {
                try {
                    Thread.sleep(20);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(Thread.currentThread().getName() + " : " + i);
            }
        }
    }

    private static List<Thread> threads() {
        return List.of(
                new Thread(new CounterImplementRunnable(), "firstCounter"),
                new Thread(new CounterImplementRunnable(), "secondCounter"),
                new Thread(new CounterImplementRunnable(), "thirdCounter")
        );
    }

    public static void main(String[] args) {
        System.out.println("===== Thread::run =====");
        ThreadUtils.runThreads(threads());
        System.out.println("===== Thread::start =====");
        ThreadUtils.startThreads(threads());
    }


}
