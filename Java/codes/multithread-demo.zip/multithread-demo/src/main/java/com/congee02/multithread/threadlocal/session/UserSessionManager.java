package com.congee02.multithread.threadlocal.session;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class UserSessionManager {

    private static final ThreadLocal<Map<String, Object>> threadLocalSession = ThreadLocal.withInitial(HashMap::new);

    public static Map<String, Object> notNullCheckedCurrentSessionMap() {
        return Objects.requireNonNull(threadLocalSession.get());
    }

    public static void setSessionAttribute(String key, Object value) {
        notNullCheckedCurrentSessionMap().put(key, value);
    }

    public static Object getSessionAttribute(String key) {
        return notNullCheckedCurrentSessionMap().get(key);
    }

    public static void clearSession() {
        Map<String, Object> currentSessionMap = notNullCheckedCurrentSessionMap();
        try {
            currentSessionMap.clear();      // help GC
        } finally {
            threadLocalSession.remove();    // avoid resource leaking
        }
    }

    public static void main(String[] args) {
        setSessionAttribute("Greeting", "Hello");
        System.out.println("From " + Thread.currentThread().getName() + ": " + getSessionAttribute("Greeting"));
        new Thread(() -> {
            System.out.println("From " + Thread.currentThread().getName() + ": " + getSessionAttribute("Greeting"));
        }).start();
        clearSession();
    }

}
