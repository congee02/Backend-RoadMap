package com.congee02.multithread.threadlocal.memleak;

public class ThreadLocalMemoryLeaking {

    private static class Object50M {
        private byte[] b = new byte[1024 * 1024 * 50];
        @Override
        protected void finalize() throws Throwable {
            System.out.println("Object50M 50MB finalized...");
        }
    }


    public static void main(String[] args) throws InterruptedException {
        ThreadLocal threadLocal = new ThreadLocal() {
            private byte[] b = new byte[1024 * 1024 * 1];

            @Override
            protected void finalize() throws Throwable {
                System.out.println("threadLocal 1MB finalized");
            }
        };
        threadLocal.set(new Object50M());
        threadLocal = null;
        System.gc();
        Thread.sleep(3000);
    }

}
