package com.congee02.multithread.pool;

import java.util.concurrent.locks.AbstractQueuedSynchronizer;

public class CustomPoolDemo {

    public static void main(String[] args) {
        AbstractQueuedSynchronizer w;
    }

}
