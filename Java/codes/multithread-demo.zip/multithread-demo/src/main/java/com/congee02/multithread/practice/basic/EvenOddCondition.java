package com.congee02.multithread.practice.basic;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class EvenOddCondition {

    private static final Lock lock = new ReentrantLock();

    private static final Condition even = lock.newCondition();
    private static final Condition odd = lock.newCondition();

    private static int count = 0;
    private static final int MAX_COUNT = 100;

    private static final Runnable evenRunnable = () -> {
        lock.lock();
        try {
            while (count <= MAX_COUNT) {
                while ((count & 1) == 0) {
                    even.await();
                }
                System.out.println("Even: " + count ++);
                odd.signal();
                if (count >= MAX_COUNT) {
                    return;
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    };

    private static final Runnable oddRunnable = () -> {
        lock.lock();
        try {
            while (count <= MAX_COUNT) {
                while ((count & 1) == 1) {
                    odd.await();
                }
                System.out.println("Odd: " + count ++);
                even.signal();
                if (count >= MAX_COUNT) {
                    return;
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    };

    public static void main(String[] args) {
        ExecutorService pool =
                Executors.newFixedThreadPool(2);
        pool.execute(oddRunnable);
        pool.execute(evenRunnable);
        pool.shutdown();
    }

}
