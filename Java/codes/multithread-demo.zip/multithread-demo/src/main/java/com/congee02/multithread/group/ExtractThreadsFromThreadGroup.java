package com.congee02.multithread.group;

import java.util.Arrays;
import java.util.Random;

public class ExtractThreadsFromThreadGroup {

    private final static Random random = new Random();
    private final static Runnable helloRunnable = () -> {
        try {
            Thread.sleep(random.nextInt(100));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Hello from " + Thread.currentThread().getName() + ".");
    };

    private final static int THREAD_NUM = 10;

    public static void main(String[] args) {
        ThreadGroup threadGroup = new ThreadGroup("subThreadGroup");
        for (int i = 0 ; i < THREAD_NUM ; i ++ ) {
            new Thread(threadGroup, helloRunnable).start();
        }
        Thread[] extractActiveThreads = new Thread[threadGroup.activeCount()];
        threadGroup.enumerate(extractActiveThreads);
        System.out.println(Arrays.toString(extractActiveThreads));
    }

}
