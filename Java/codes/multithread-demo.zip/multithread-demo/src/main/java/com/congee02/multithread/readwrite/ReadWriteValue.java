package com.congee02.multithread.readwrite;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ReadWriteValue {

    private static final ReadWriteLock mainLock = new ReentrantReadWriteLock();
    private static final Lock writeLock = mainLock.writeLock();
    private static final Lock readLock = mainLock.readLock();

    private static final int WRITER_THREAD_NUM = 5;
    private static final int READER_THREAD_NUM = 5;

    private static volatile Object readWriteValue = "Initialization Value";


    private static final AtomicInteger readerId = new AtomicInteger(1);
    private static final ThreadFactory READER_FACTORY = r -> new Thread(r, "READER-" + readerId.getAndIncrement());

    private static final Runnable readRunnable = () -> {
        boolean success = readLock.tryLock();
        String name = Thread.currentThread().getName();
        if (! success) {
            System.out.println(name + ":" + "Read Blocked");
            readLock.lock();
        }
        try {
            System.out.println(name + ":" + "Read value: " + readWriteValue);
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            readLock.unlock();
        }
    };


    private static final AtomicInteger writerId = new AtomicInteger(1);
    private static final ThreadFactory WRITER_FACTORY = r -> {
        Thread thread = new Thread(r, "WRITER-" + writerId.getAndIncrement());
        thread.setPriority(10);
        return thread;
    };

    private static final Runnable writeRunnable = () -> {
        boolean success = writeLock.tryLock();
        String name = Thread.currentThread().getName();
        if (! success) {
            System.out.println(name + ":" + "Write Blocked");
            writeLock.lock();
        }
        try {
            String writeValue = name + "," + new Date();
            System.out.println(name + ":" + "Write value: " + writeValue);
            readWriteValue = writeValue;
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            writeLock.unlock();
        }
    };

    private static void multiThreadRead() {
        ExecutorService pool = Executors.newFixedThreadPool(READER_THREAD_NUM, READER_FACTORY);
        for (int i = 0 ; i < READER_THREAD_NUM ; i ++ ) {
            pool.execute(readRunnable);
        }
        pool.shutdown();
        while (! pool.isTerminated()) {}
        readerId.set(0);
    }

    private static void multiThreadWrite() {
        ExecutorService pool = Executors.newFixedThreadPool(WRITER_THREAD_NUM, WRITER_FACTORY);
        for (int i = 0 ; i < WRITER_THREAD_NUM ; i ++ ) {
            pool.execute(writeRunnable);
        }
        pool.shutdown();
        while (! pool.isTerminated()) {}
        writerId.set(0);
    }

    private static void multiThreadReadWrite() {
        ExecutorService readerPool = Executors.newFixedThreadPool(READER_THREAD_NUM, READER_FACTORY);
        ExecutorService writerPool = Executors.newFixedThreadPool(WRITER_THREAD_NUM, WRITER_FACTORY);
        Random random = new Random();
        for (int i = 0 ; i < READER_THREAD_NUM + WRITER_THREAD_NUM ; i ++ ) {
            if (random.nextBoolean()) {
                readerPool.execute(readRunnable);
            } else {
                writerPool.execute(writeRunnable);
            }
        }
        readerPool.shutdown();
        writerPool.shutdown();
    }


    public static void main(String[] args) {
        System.out.println("========== multiThreadRead ==========");
        multiThreadRead();
        System.out.println("========== multiThreadWrite ==========");
        multiThreadWrite();
        System.out.println("========== multiThreadReadWrite ==========");
        multiThreadReadWrite();
    }

}
