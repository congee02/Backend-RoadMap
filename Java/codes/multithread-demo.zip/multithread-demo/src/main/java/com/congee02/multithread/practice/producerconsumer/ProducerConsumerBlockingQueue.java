package com.congee02.multithread.practice.producerconsumer;

import java.util.Random;
import java.util.concurrent.*;

public class ProducerConsumerBlockingQueue {

    private static final int SHARED_BUFFER_SIZE = 10;
    private static final ArrayBlockingQueue<String> SHARED_BUFFER = new ArrayBlockingQueue<>(SHARED_BUFFER_SIZE);

    private static final int PRODUCT_NUM_PER_PRODUCER = 10;
    private static final String PRODUCT_PREFIX = "product-";
    private static int productId = 0;

    private static final int PRODUCER_NUM = 5;
    private static final int CONSUMER_NUM = PRODUCER_NUM;

    private static final String PRODUCER_PREFIX = "PRODUCER-";
    private static final String CONSUMER_PREFIX = "CONSUMER-";

    private static String prefixId(String prefix, int id) {
        return prefix + id;
    }

    private static class PrefixThreadFactory implements ThreadFactory {

        private final String prefix;
        private int id;

        private PrefixThreadFactory(String prefix) {
            this.prefix = prefix;
            this.id = 0;
        }

        @Override
        public Thread newThread(Runnable r) {
            return new Thread(r, prefixId(this.prefix, this.id ++));
        }
    }

    private final static Runnable producerRunnable = () -> {
        String product = prefixId(PRODUCT_PREFIX, productId ++);
        String name = Thread.currentThread().getName();
        try {
            for (int i = 0 ; i < PRODUCT_NUM_PER_PRODUCER ; i ++ ) {
                System.out.println(name + ": produces " + product);
                System.out.println(name + ": trying to put " + product + " into shared buffer");
                boolean success = SHARED_BUFFER.offer(product);
                if (! success) {
                    System.out.println(name + ": the shared buffer is full, waiting...");
                    SHARED_BUFFER.put(product);
                }
                System.out.println(name + ": has put " + product + " into shared buffer");
                TimeUnit.SECONDS.sleep(new Random().nextInt(2));
            }
        } catch (InterruptedException e) {
            System.out.println("Monitor handle " + e);
        }
    };

    private final static Runnable consumerRunnable = () -> {
        String name = Thread.currentThread().getName();
        try {
            for (int i = 0 ; i < PRODUCT_NUM_PER_PRODUCER ; i ++ ) {
                System.out.println(name + ": trying to take a product from shared buffer");
                String product = SHARED_BUFFER.poll();
                boolean success = product != null;
                if (! success) {
                    System.out.println(name + ": the shared buffer is empty, waiting...");
                    product = SHARED_BUFFER.take();
                }
                System.out.println(name + ": has taken " + product + " from shared buffer");
                TimeUnit.SECONDS.sleep(new Random().nextInt(2));
            }
        } catch (InterruptedException e) {
            System.out.println("Monitor handle " + e);
        }
    };

    public static void main(String[] args) {
        ExecutorService producerPool =
                Executors.newFixedThreadPool(PRODUCER_NUM, new PrefixThreadFactory(PRODUCER_PREFIX));
        for (int i = 0 ; i < PRODUCER_NUM ; i ++ ) {
            producerPool.execute(producerRunnable);
        }
        ExecutorService consumerPool =
                Executors.newFixedThreadPool(CONSUMER_NUM, new PrefixThreadFactory(CONSUMER_PREFIX));
        for (int i = 0 ; i < CONSUMER_NUM ; i ++ ) {
            consumerPool.execute(consumerRunnable);
        }
        producerPool.shutdown();
        consumerPool.shutdown();
    }

}
