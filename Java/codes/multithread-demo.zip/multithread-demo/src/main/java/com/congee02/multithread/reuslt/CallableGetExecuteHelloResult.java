package com.congee02.multithread.reuslt;

import java.util.ArrayList;
import java.util.concurrent.*;

public class CallableGetExecuteHelloResult {

    private final static int TASK_NUM = 10;

    public static void main(String[] args) {

        // 创建一个包含五个线程的线程池
        ExecutorService executorService = Executors.newFixedThreadPool(5);

        // 创建一个 Callable 任务
        Callable<String> task = () -> "Hello from " + Thread.currentThread().getName();

        // 提交任务到 ExecutorService 对象中执行，获取 Future 对象
        ArrayList<Future<String>> futures = new ArrayList<>(TASK_NUM);
        for (int i = 0 ; i < TASK_NUM ; i ++ ) {
            Future<String> future = executorService.submit(task);
            futures.add(future);
        }

        // 通过 Future 获取任务结果
        futures.stream().map(future -> {
            try {
                return future.get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
            return null;
        }).forEach(System.out::println);

        // 关闭 ExecutorService 对象，不再接受新的任务，等待所有已提交的任务完成
        executorService.shutdown();

    }
}
