package com.congee02.multithread.sychronizedc;

/**
 * 双重检查锁单例模式
 */
public final class DoubleCheckSingleton {

    private static volatile DoubleCheckSingleton instance;

    private DoubleCheckSingleton() {}

    public static DoubleCheckSingleton doubleCheckGetInstance() {
        // 防止拿到 null
        if (instance == null) {
            // 只允许一个线程进入
            synchronized (DoubleCheckSingleton.class) {
                // 只允许一个线程实例化 instance
                if (instance == null) {
                    instance = new DoubleCheckSingleton();
                }
            }
        }
        return instance;
    }
}
