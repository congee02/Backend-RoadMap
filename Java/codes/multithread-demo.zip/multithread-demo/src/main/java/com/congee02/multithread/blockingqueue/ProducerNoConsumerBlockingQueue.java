package com.congee02.multithread.blockingqueue;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ProducerNoConsumerBlockingQueue {

    private static final int BUFFER_SIZE = 3;

    private static final BlockingQueue<String> BUFFER = new ArrayBlockingQueue<>(BUFFER_SIZE);

    private static final String BUFFER_ELEMENT_PREFIX = "buffer-";

    private static final Runnable producerRunnable = () -> {
        try {
            for (int i = 0 ; i < 10 ; i ++ ) {
                String currentProduct = BUFFER_ELEMENT_PREFIX + i;
                Thread.sleep(1);
                // 尝试添加产品到缓冲区
                boolean notFull = BUFFER.offer(currentProduct);
                // 若失败，则阻塞等待缓冲区不满，然后添加产品。
                if (! notFull) {
                    System.out.println("队列已满，阻塞等待队列有空位");
                    BUFFER.put(currentProduct);
                }
                System.out.println("产品 " + currentProduct + " 已经放入缓冲区中");
            }
        } catch (InterruptedException e) {
            System.err.println(e.getMessage());
        }
    };

    public static void main(String[] args) {
        Thread producer
                = new Thread(producerRunnable, "ProducerNoConsumerBlockingQueue-Producer");
        producer.start();
    }

}
