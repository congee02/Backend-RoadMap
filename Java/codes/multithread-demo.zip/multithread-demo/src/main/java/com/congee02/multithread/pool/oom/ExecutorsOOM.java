package com.congee02.multithread.pool.oom;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ExecutorsOOM {

    private static final ExecutorService service = Executors.newFixedThreadPool(10);

    private static final Runnable task = () -> {
        try {
            TimeUnit.SECONDS.sleep(10);
        } catch (InterruptedException e) {
        }
    };

    public static void main(String[] args) {
        for (int i = 0 ; i < Integer.MAX_VALUE ; i ++ ) {
            service.execute(task);
        }
        service.shutdown();
    }

}
