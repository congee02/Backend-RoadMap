package com.congee02.multithread.reentrantlock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockTimeout {

    // 公平锁
    private static final Lock lock = new ReentrantLock(true);

    private final static Runnable r1 = () -> {
        boolean isLocked = lock.tryLock();
        if (isLocked) {
            try {
                System.out.println(Thread.currentThread().getName() + " acquire lock.");
                Thread.sleep(4000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                lock.unlock();
            }
        }
        else {
            System.out.println(Thread.currentThread().getName() + " could not acquire the lock.");
        }
        System.out.println(Thread.currentThread().getName() + " done.");
    };

    private static final Runnable r2 = () -> {
        boolean isLocked = false;
        try {
            isLocked = lock.tryLock(3, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (isLocked) {
            try {
                System.out.println(Thread.currentThread().getName() + " acquire lock.");
            } finally {
                lock.unlock();
            }
        }
        else {
            System.out.println(Thread.currentThread().getName() + " could not acquire the lock.");
        }
    };

    public static void main(String[] args) {
        // 因为是公平锁，t1 总是第一个获取锁的线程
        Thread t1 = new Thread(r1, "t1");
        Thread t2 = new Thread(r2, "t2");
        t1.start();
        t2.start();
    }

}
