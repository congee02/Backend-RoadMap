package com.congee02.multithread.state;

import com.congee02.multithread.MuteOutputStream;

import java.io.PrintStream;

public class ThreadStateTransition {

    public static void main(String[] args) {

        PrintStream muteOut = new PrintStream(new MuteOutputStream());
        Thread thread = new Thread(() -> {
            for (int i = 0; i < 5; i++) {
                muteOut.println("Working");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        Thread.State previousState = thread.getState();
        thread.start();
        Thread.State currentState = thread.getState();
        printStateTransitionIfNecessary(previousState, currentState);

        while (true) {
            currentState = thread.getState();
            if (currentState != previousState) {
                printStateTransitionIfNecessary(previousState, currentState);
                previousState = currentState;
            }

            if (currentState == Thread.State.TERMINATED) {
                break;
            }
        }

    }

    private static void printStateTransitionIfNecessary(Thread.State prevState, Thread.State currentThread) {
        if (currentThread != prevState) {
            System.out.println("===== Transition triggered =====");
            System.out.println(prevState + " -> " + currentThread);
            System.out.println();
        }
    }

}
