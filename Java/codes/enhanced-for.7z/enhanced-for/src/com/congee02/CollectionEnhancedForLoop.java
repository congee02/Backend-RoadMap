package com.congee02;

import java.util.ArrayList;
import java.util.Arrays;

public class CollectionEnhancedForLoop {

    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 3, 4));
        for (int i : list) {
            System.out.println(i);
        }
    }

}
