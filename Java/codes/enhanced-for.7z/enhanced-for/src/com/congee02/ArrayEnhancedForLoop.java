package com.congee02;

import java.util.Arrays;

public class ArrayEnhancedForLoop {

    public static void main(String[] args) {
        Integer[] is = {1, 2, 3};
        // 增强 for 循环仅提供数据的视图
        for (Integer i : is) {
            i += 1;
        }
        System.out.println(Arrays.toString(is));
    }

}
