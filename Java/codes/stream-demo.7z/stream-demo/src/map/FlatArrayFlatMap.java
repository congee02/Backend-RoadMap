package map;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FlatArrayFlatMap {

    public static void main(String[] args) {
        List<List<Integer>> listOfLists = List.of(
                List.of(1, 2, 3),
                List.of(4, 5, 6),
                List.of(7, 8, 9)
        );
        Stream<List<Integer>> listStream = listOfLists.stream();
        List<Integer> flatList = listStream.flatMap(Collection::stream).collect(Collectors.toList());
        System.out.println(flatList);
    }

}
