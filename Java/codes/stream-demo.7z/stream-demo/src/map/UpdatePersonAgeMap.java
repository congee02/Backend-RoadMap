package map;

import entity.Person;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class UpdatePersonAgeMap {

    public static void main(String[] args) {
        HashSet<Person> set = new HashSet<>(List.of(
                new Person("Alice", 21),
                new Person("Bob", 30),
                new Person("Seaborn", 20)
        ));
        System.out.println("====================================== Data to be updated ======================================");
        System.out.println(set);
        Set<Person> updatedSet = null;
        try (final Stream<Person> stream = set.stream()) {
             updatedSet = stream.map(p -> new Person(p.getName(), p.getAge() + 5)).collect(Collectors.toSet());
        }
        System.out.println("====================================== Updated data (Age plus 5) ======================================");
        System.out.println(updatedSet);
    }

}
