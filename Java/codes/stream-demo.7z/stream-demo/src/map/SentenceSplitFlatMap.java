package map;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SentenceSplitFlatMap {

    public static void main(String[] args) {

        List<String> sentences = List.of(
                "Hello world",
                "Java Stream API",
                "FlatMap example"
        );

        try (Stream<String> stream = sentences.stream()) {
            final List<String> words = stream.map(sentence -> sentence.split(" "))
                    .flatMap(Arrays::stream)
                    .collect(Collectors.toList());
            System.out.println(words);
        }
    }

}
