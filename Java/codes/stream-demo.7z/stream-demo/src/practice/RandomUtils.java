package practice;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class RandomUtils {

    private RandomUtils() {}

    public static int randomInteger(int bound) {
        return randomInteger(bound, false);
    }
    public static int randomInteger(int bound, boolean withSign) {
        return new Random().nextInt(bound) * (withSign ? randomSign() : 1);
    }


    public static boolean randomBool() {
        return new Random().nextDouble() > 0.5D;
    }

    public static int randomSign() {
        return randomBool() ? 1 : -1;
    }

    public static List<Integer> randomIntegerList(int length, int base, int bound) {
        Random random = new Random();
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0 ; i < length ; i ++ ) {
            list.add((base + random.nextInt(bound)) * randomSign());
        }
        return list;
    }

    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    public static String generateRandomString(int length) {
        Random random = new Random();
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(CHARACTERS.length());
            char randomChar = CHARACTERS.charAt(randomIndex);
            stringBuilder.append(randomChar);
        }

        return stringBuilder.toString();
    }

    public static String generateRandomString() {
        return generateRandomString(5, 46);
    }

    public static String generateRandomString(int baseLength, int boundLength) {
        return generateRandomString(randomInteger(boundLength) + baseLength);
    }

    public static List<String> generateRandomStringList(int length) {
        ArrayList<String> result = new ArrayList<>();
        for (int i = 0 ; i < length ; i ++ ) {
            result.add(generateRandomString());
        }
        return result;
    }

    public static List<String> generateRandomStringList(int length, int baseLength, int boundLength) {
        ArrayList<String> result = new ArrayList<>();
        for (int i = 0 ; i < length ; i ++ ) {
            result.add(generateRandomString(baseLength, boundLength));
        }
        return result;
    }


}
