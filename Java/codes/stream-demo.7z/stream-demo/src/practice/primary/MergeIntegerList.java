package practice.primary;

import practice.RandomUtils;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 将两个整数列表合并为一个列表，然后去除重复元素
 */
public class MergeIntegerList {

    public static void main(String[] args) {

        List<Integer> firstList = RandomUtils.randomIntegerList(20, 10, 10);
        List<Integer> secondList = RandomUtils.randomIntegerList(20, 10, 10);

        firstList.sort(Comparator.comparingInt(x -> x));
        secondList.sort(Comparator.comparingInt(x -> x));

        System.out.println("firstList = " + firstList);
        System.out.println("secondList = " + secondList);

        List<Integer> mergeDistinctList =
                Stream.of(firstList, secondList).flatMap(Collection::stream).distinct().collect(Collectors.toList());
        System.out.println("mergeDistinctList = " + mergeDistinctList);

    }

}
