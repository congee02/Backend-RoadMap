package practice.primary;

import practice.RandomUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 从列表中筛选出所有偶数。
 */
public class EvenSieve {

    public static void main(String[] args) {
        List<Integer> list = RandomUtils.randomIntegerList(20, 80 + 1, 20);
        List<Integer> evenList = list.stream().filter(n -> (n & 1) == 0).collect(Collectors.toList());
        System.out.println("evenList: " + evenList);
    }

}
