package practice.primary;


import java.util.List;
import java.util.stream.Collectors;

/**
 * 找出列表中长度大于等于5的字符串
 */
public class LengthGreater5String {

    public static void main(String[] args) {
        List<String> list = List.of("apple", "banana", "kiwi", "grape", "orange");
        System.out.println(list.stream().filter(s -> s.length() >= 5).collect(Collectors.toList()));
    }

}
