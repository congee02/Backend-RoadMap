package practice.primary;

import practice.RandomUtils;

import java.util.Collection;
import java.util.HashSet;
import java.util.stream.Collectors;

/**
 * 计算列表中所有正整数的平均值。
 */
public class PositiveIntegerAverage {

    private static Collection<Integer> collection() {
        HashSet<Integer> set = new HashSet<>();
        for (int i = 0 ; i < 10 ; i ++ ) {
            set.add(RandomUtils.randomInteger(80) * RandomUtils.randomSign());
        }
        return set;
    }

    public static void main(String[] args) {
        Collection<Integer> collection = collection();

        double average = collection.stream()
                .filter(element -> element > 0)                 // 筛选出正整数
                .mapToDouble(Integer::doubleValue)              // 将正整数转为双精度浮点数
                .average()                                      // 取其平均值，返回 OptionalDouble 对象
                .orElse(0.0)                              // 若 OptionalDouble isEmpty 取 0.0
                ;
        System.out.println(average);

        double averageBySummarizing = collection.stream().filter(element -> element > 0).collect(Collectors.summarizingInt(e -> e)).getAverage();
        System.out.println(averageBySummarizing);
    }

}
