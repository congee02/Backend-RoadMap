package practice.primary;

import practice.RandomUtils;

import java.util.Comparator;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 找出列表中的最大值和最小值。
 */
public class FindMinMaxInList {

    public static void main(String[] args) {
        List<Integer> list =
                RandomUtils.randomIntegerList(20, 21, 80);
        System.out.println(list);

        /* SUMMARIZING */
        System.out.println("/* SUMMARIZING */");
        IntSummaryStatistics statistics = list.stream().collect(Collectors.summarizingInt(element -> element));
        System.out.println("Min: " + statistics.getMax());
        System.out.println("Max: " + statistics.getMin());

        /* MAX, MIN */
        System.out.println("/* MAX, MIN */");
        Optional<Integer> min = list.stream().max(Comparator.comparingInt(x -> x));
        Optional<Integer> max = list.stream().min(Comparator.comparingInt(x -> x));
        System.out.println("Min: " + min.orElse(Integer.MAX_VALUE));
        System.out.println("Max: " + max.orElse(Integer.MIN_VALUE));
    }

}
