package practice.primary;

import practice.RandomUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 将整数列表中的所有元素平方后生成新的列表
 */
public class IntegerSquare {

    public static void main(String[] args) {
        List<Integer> list =
                RandomUtils.randomIntegerList(20, 0, 40);

        List<Integer> squareList = list.stream().map(e -> e * e).collect(Collectors.toList());
        System.out.println(list);
        System.out.println(squareList);
    }

}
