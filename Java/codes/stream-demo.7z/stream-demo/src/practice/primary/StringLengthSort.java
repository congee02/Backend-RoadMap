package practice.primary;

import practice.RandomUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 将字符串列表按照长度排序
 */
public class StringLengthSort {

    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        for (int i = 0 ; i < 10 ; i ++ ) {
            list.add(RandomUtils.generateRandomString());
        }
        List<String> sortedList = list.stream().sorted(Comparator.comparingInt(String::length)).collect(Collectors.toList());
        sortedList.forEach(System.out::println);
    }

}
