package practice.primary;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 将字符串列表转换为大写。
 */
public class StringTransferToUpperCase {

    private static List<String> words = Arrays.asList(
            "apple", "banana", "car", "dog", "elephant",
            "flower", "guitar", "house", "ice cream", "jacket",
            "kite", "lamp", "moon", "notebook", "orange",
            "pineapple", "queen", "rainbow", "sun", "tree"
    );

    public static void main(String[] args) {
        StringTransferToUpperCase.words.stream()
                .map(s -> s.toUpperCase())          // 一对一的全部转为大写
                .collect(Collectors.toList())       // 收集结果成集合
        ;
    }

}
