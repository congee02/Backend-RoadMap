package practice.advanced;

import practice.RandomUtils;

import java.util.List;

/**
 * 计算列表中所有数字的平方和，使用map和reduce操作
 */
public class SquareSumByMapAndReduce {

    public static void main(String[] args) {
        List<Integer> list =
                RandomUtils.randomIntegerList(5, 0, 10);
        System.out.println(list);
        long squareSummation = list.stream().mapToLong(x -> x).reduce(0L, (acc, x) -> acc + x * x);
        System.out.println(squareSummation);
    }

}
