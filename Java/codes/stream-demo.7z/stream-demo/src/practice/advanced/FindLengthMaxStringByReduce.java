package practice.advanced;

import practice.RandomUtils;

import java.util.List;

/**
 * 找出列表中长度最长的字符串的长度，使用reduce操作
 */
public class FindLengthMaxStringByReduce {

    public static void main(String[] args) {
        List<String> list = RandomUtils.generateRandomStringList(100);
        String lengthMaxString = list.stream().reduce("", (acc, x) -> acc.length() > x.length() ? acc : x);
        System.out.println(lengthMaxString);
    }

}
