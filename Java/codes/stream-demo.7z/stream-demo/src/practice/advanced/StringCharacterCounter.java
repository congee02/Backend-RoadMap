package practice.advanced;

import practice.RandomUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 统计列表中每个字符串中每个字符出现的次数
 */
public class StringCharacterCounter {

    public static void main(String[] args) {
        List<String> list = RandomUtils.generateRandomStringList(20);
        Map<Character, Long> map = list.stream().flatMap(s -> s.chars().mapToObj(c -> (char) c)).collect(
                Collectors.groupingBy(
                        c -> c,                 // 分类依据
                        Collectors.counting()   // 对分完类的各组继续进行操作
                )
        );
        System.out.println(map);
    }

}
