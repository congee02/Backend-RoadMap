package practice.advanced;

import practice.RandomUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 找出列表中所有的质数
 */
public class FindPrimeNumber {

    public static void main(String[] args) {
        List<Integer> list =
                RandomUtils.randomIntegerList(100, 20, 81);
        List<Integer> primeList = list.stream()
                .filter(FindPrimeNumber::prime)
                .collect(Collectors.toList());
        System.out.println(primeList);
    }

    private static boolean prime(int n) {
        if (n < 1) {
            return false;
        }
        if (n == 1) {
            return true;
        }
        for (int i = 2 ; i < Math.sqrt(n) ; i ++ ) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

}
