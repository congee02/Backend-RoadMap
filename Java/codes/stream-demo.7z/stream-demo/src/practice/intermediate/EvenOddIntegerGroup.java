package practice.intermediate;

import practice.RandomUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 将整数列表分组，使得奇数和偶数分开。
 */
public class EvenOddIntegerGroup {

    public static void main(String[] args) {
        List<Integer> list = RandomUtils.randomIntegerList(100, 20, 81);
        Map<Boolean, List<Integer>> evenOddGroupMap = list.stream().collect(Collectors.groupingBy(element -> ((element & 1) == 0)));
        evenOddGroupMap.entrySet().forEach(System.out::println);
    }

}
