package practice.intermediate;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 将列表中的字符串按照字母顺序排序，并去除重复项。
 */
public class StringDictionarySortDistinct {

    private static List<String> list() {
        List<String> strings = new ArrayList<>();
        strings.add("apple");
        strings.add("orange");
        strings.add("banana");
        strings.add("apple");
        strings.add("kiwi");
        strings.add("banana");
        return strings;
    }

    public static void main(String[] args) {
        List<String> list = list();
        List<String> distinctSortedStringList = list.stream().distinct().sorted().collect(Collectors.toList());
        System.out.println(distinctSortedStringList);
    }

}
