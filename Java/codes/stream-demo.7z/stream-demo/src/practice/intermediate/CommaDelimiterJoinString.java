package practice.intermediate;

import practice.RandomUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 将字符串列表中的元素连接成一个以逗号分隔的字符串
 */
public class CommaDelimiterJoinString {

    public static void main(String[] args) {
        List<String> list =
                RandomUtils.generateRandomStringList(10);
        list.forEach(System.out::println);
        String commaJoinString = list.stream().collect(Collectors.joining(",\n"));
        System.out.println(commaJoinString);
    }

}
