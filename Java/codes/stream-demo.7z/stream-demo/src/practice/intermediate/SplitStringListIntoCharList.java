package practice.intermediate;

import practice.RandomUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 将字符串列表中的每个字符串的每个字符拆分成一个字符列表。
 */
public class SplitStringListIntoCharList {

    public static void main(String[] args) {
        List<String> list = RandomUtils.generateRandomStringList(20);
        List<Character> letters = list.stream()
                .flatMapToInt(String::chars)        // 转为 IntStream
                .mapToObj(i -> (char) i)            // 转为 Stream<Character>
                .collect(Collectors.toList());      // 收集结果
        System.out.println(letters);
    }

}
