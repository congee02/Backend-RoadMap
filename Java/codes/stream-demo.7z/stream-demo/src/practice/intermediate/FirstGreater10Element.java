package practice.intermediate;

import practice.RandomUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 找出列表中第一个大于10的元素。
 */
public class FirstGreater10Element {

    public static void main(String[] args) {
        List<Integer> list =
                RandomUtils.randomIntegerList(100, 0, 20);
        System.out.println(list);

        // 使用 takeWhile 方法获取满足条件的元素，直到遇到第一个不满足条件的元素，然后统计满足条件的元素个数
        long resultIndex = list.stream().takeWhile(integer -> integer <= 10).collect(Collectors.toList()).stream().count();

        // 输出满足条件的元素个数和第一个大于 10 的元素的值
        System.out.println("resultIndex: " + resultIndex + "; result: " + list.get((int) resultIndex));
    }

}
