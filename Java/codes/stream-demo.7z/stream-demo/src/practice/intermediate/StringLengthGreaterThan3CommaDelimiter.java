package practice.intermediate;

import practice.RandomUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 找出列表中长度大于等于3的字符串，并将它们以逗号分隔的形式输出。
 */
public class StringLengthGreaterThan3CommaDelimiter {

    public static void main(String[] args) {
        List<String> list = RandomUtils.generateRandomStringList(100, 1, 10);
        String result = list.stream().filter(s -> s.length() > 3).collect(Collectors.joining(",\n"));
        System.out.println(result);
    }

}
