package practice.intermediate;

import practice.RandomUtils;

import java.util.List;

/**
 * 计算列表中所有数字的乘积。
 */
public class AllNumberMultiplication {

    public static void main(String[] args) {
        List<Integer> list =
                RandomUtils.randomIntegerList(5, 1, 10);
        System.out.println(list);
        System.out.println(list.stream().mapToLong(x -> x).reduce(1L, (acc, x) -> acc * x));
    }

}
