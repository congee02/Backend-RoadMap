package practice.intermediate;

import practice.RandomUtils;

import java.util.Comparator;
import java.util.List;

/**
 * 找出列表中长度最长的字符串。
 */
public class LengthMaxString {

    public static void main(String[] args) {
        List<String> list =
                RandomUtils.generateRandomStringList(10);
        String maxLengthString = list.stream().max(Comparator.comparingInt(String::length)).orElseThrow();
        System.out.println(maxLengthString);
    }

}
