package match;

import java.util.ArrayList;
import java.util.List;

public class NameMatch {

    public static void main(String[] args) {
        ArrayList<String> nameList = new ArrayList<>(List.of(
                "周杰伦",
                "王力宏",
                "陶喆",
                "林俊杰"
        ));
        // 查看列表中是否有任何一个姓王的姓名
        boolean anyWangSurname = nameList.stream().anyMatch(name -> name.startsWith("王"));
        System.out.println(anyWangSurname);

        // 查看列表是不是所有名字都是双字名
        boolean allDoubleName = nameList.stream().allMatch(name -> name.length() == 2);
        System.out.println(allDoubleName);

        // 查看列表中是否没有姓伍的姓名
        boolean noneWuSurname = nameList.stream().noneMatch(name -> name.startsWith("伍"));
        System.out.println(noneWuSurname);

    }

}
