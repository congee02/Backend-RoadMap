package match;

import java.util.List;
import java.util.stream.Stream;

public class EvenNumberMatch {

    public static void main(String[] args) {
        List<Integer> numbers = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        // 查看是否所有元素都是偶数
        boolean allEven = numbers.stream().allMatch(n -> (n & 1) == 0);
        System.out.println("All elements are even: " + allEven);

        // 查看是否有任何一个元素是偶数
        boolean anyEven = numbers.stream().anyMatch(n -> (n & 1) == 0);
        System.out.println("Any element is even: " + anyEven);

        // 查看是整数集合中是不是没有任何负数
        boolean noneNegative = numbers.stream().noneMatch(n -> n < 0);
        System.out.println("None of the elements are negative: " + noneNegative);

    }

}
