package example;

import java.util.*;
import java.util.stream.Stream;

public class StringDistinctExample {

    public static void main(String[] args) {

        List<String> list = new ArrayList<>();

        list.add("武汉加油");
        list.add("中国加油");
        list.add("世界加油");
        list.add("世界加油");

        long distinctCount = -1;
        try (Stream<String> stream = list.stream();) {
            // 中间操作 去重
            Stream<String> distinctStream = stream.distinct();
            // 终端操作 终端方法
            distinctCount = distinctStream.count();
        }

        System.out.println(distinctCount);
    }

}
