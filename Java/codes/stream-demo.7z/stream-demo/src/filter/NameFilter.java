package filter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class NameFilter {

    public static void main(String[] args) {
        final ArrayList<String> list = new ArrayList<>(List.of("王力宏", "王一博", "王晨", "邵贵龙", "李芙蓉", "王媛", "大王叫我来巡山"));
        try (Stream<String> stream = list.stream()) {
             stream.filter(element -> element.contains("王")).forEach(System.out::println);
        }
    }

}
