package result;

import entity.Department;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class EntityIdCollect {

    public static void main(String[] args) {
        List<Department> list =
                Arrays.asList(new Department(17L), new Department(85L), new Department(100L), new Department(100L));

        // 1. collect 成 set
        Set<Long> idSet =
                list.stream().map(Department::getDeptId).collect(Collectors.toSet());
        System.out.println("idSet: " + idSet);

        // 2. collect 成 list
        List<Long> idList =
                list.stream().map(Department::getDeptId).collect(Collectors.toList());
        System.out.println("idList: " + idList);

        // 3. collect 成 map
        Map<Department, Long> idMap =
                list.stream().distinct().collect(Collectors.toMap(x -> x, Department::getDeptId));
        System.out.println(idMap);
    }

}
