package result;

import java.util.Arrays;
import java.util.List;

public class StringJoinCollect {

    public static void main(String[] args) {
        List<String> list = Arrays.asList(
                "你好",
                "我好",
                "大家好"
        );
        String joinString = list.stream().collect(new StringJoinCollector());
        System.out.println(joinString);
    }

}
