package result;

import java.util.Arrays;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;

public class StringJoinWithDelimiterCollect {

    public static void main(String[] args) {
        List<String> list = Arrays.asList(
                "你好",
                "我好",
                "大家好"
        );
        // Collectors.joining(", ") 的底层是 StringJoiner
        String collect = list.stream().collect(Collectors.joining(", "));
        System.out.println(collect);
    }

}
