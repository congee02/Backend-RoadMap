package result;

import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;

public class DataProcessCollect {

    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(10, 20, 30, 40, 50);

        // 输出 element / 10 的平均值
        Double average = numbers.stream().collect(Collectors.averagingInt(value -> value / 10));
        System.out.println(average);

        // 输出 element / 2 的个数，总和，最小值，平均值，最大值
        IntSummaryStatistics statistic = numbers.stream().collect(Collectors.summarizingInt(n -> n / 2));
        System.out.println(statistic);

    }

}
