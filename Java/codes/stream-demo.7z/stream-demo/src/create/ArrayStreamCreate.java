package create;

import java.util.Arrays;
import java.util.stream.Stream;

public class ArrayStreamCreate {

    private final static int STREAM_ARRAY_SIZE = 1000;
    private final static Integer[] STREAM_ARRAY = new Integer[STREAM_ARRAY_SIZE];

    static {
        for (int i = 0 ; i < 1000 ; i ++ ) {
            STREAM_ARRAY[i] = i;
        }
    }


    private static Stream<Integer> createStreamWithArraysStream() {
        return Arrays.stream(STREAM_ARRAY);
    }

    /**
     *
     * public static<T> Stream<T> of(T... values) {
     *     return Arrays.stream(values);
     * }
     *
     */
    private static Stream<Integer> createStreamWithStreamOf() {
        return Stream.of(STREAM_ARRAY);
    }

    public static void main(String[] args) {
        System.out.println("=====  Arrays.stream(array) CREATE =====");
        try (Stream<Integer> stream = createStreamWithArraysStream()) {
            stream.forEach(System.out::println);
        }

        System.out.println("=====  Stream.of(array) CREATE =====");
        try (Stream<Integer> stream = createStreamWithStreamOf()) {
            stream.forEach(System.out::println);
        }

    }

}
