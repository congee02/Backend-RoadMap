package create;

import java.util.*;
import java.util.stream.Stream;

public class CollectionStreamCreate {

    private static final int COLLECTION_DATA_SIZE = 1000;
    private static final Set<String> STRING_SET = new HashSet<>(COLLECTION_DATA_SIZE);
    private static final Queue<String> STRING_QUEUE = new LinkedList<>();

    static {
        for (int i = 0 ; i < COLLECTION_DATA_SIZE ; i ++ ) {
            STRING_SET.add("Set Item " + i);
        }
        for (int i = 0 ; i < COLLECTION_DATA_SIZE ; i ++ ) {
            STRING_QUEUE.add("Queue Item " + i);
        }
    }

    public static void main(String[] args) {

        Collection<String> setCollection = STRING_SET;
        Collection<String> queueCollection = STRING_QUEUE;

        try (
                final Stream<String> setStream = setCollection.stream();
                final Stream<String> queueStream = queueCollection.stream()
        ) {
            System.out.println("SET STREAM COUNT: " + setStream.count());
            System.out.println("QUEUE STREAM COUNT: " + queueStream.count());
        }

    }

}
