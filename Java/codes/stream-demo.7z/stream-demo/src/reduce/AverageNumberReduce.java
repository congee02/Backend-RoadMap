package reduce;

import java.util.ArrayList;
import java.util.Random;

public class AverageNumberReduce {

    private static final int SAMPLE_NUM = 100;

    public static void main(String[] args) {

        Random random = new Random();
        ArrayList<Double> scores = new ArrayList<>();
        for (int i = 0 ; i < SAMPLE_NUM ; i ++ ) {
            int append = random.nextInt(20) + 81;
            scores.add((double) append);
        }

        double initialValue = 0;
        System.out.println(scores.stream().reduce(initialValue, (x, y) -> (x + y / (double) SAMPLE_NUM)));

    }

}
