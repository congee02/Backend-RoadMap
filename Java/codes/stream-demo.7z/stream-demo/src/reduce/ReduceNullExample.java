package reduce;

import java.util.List;
import java.util.Optional;

public class ReduceNullExample {

    public static void main(String[] args) {
        List<Integer> list = List.of();
        Optional<Integer> sum = list.stream().reduce(
                (x, y) -> x + y
        );
        if (sum.isPresent()) {
            System.out.println("SUMMATION: " + sum);
        } else {
            System.out.println("列表为空，没有计算结果");
        }
    }

}
