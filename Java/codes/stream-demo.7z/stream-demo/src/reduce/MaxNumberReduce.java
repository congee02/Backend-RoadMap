package reduce;

import java.util.ArrayList;

public class MaxNumberReduce {

    public static void main(String[] args) {
        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i = 0 ; i < 10 ; i ++ ) {
            numbers.add(i);
        }
        int initialValue = Integer.MIN_VALUE;
        Integer maxValue = numbers.stream().reduce(initialValue, (x, y) -> x > y ? x : y);
        System.out.println("The max value of the list: " + maxValue);
    }

}
