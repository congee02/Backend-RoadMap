package reduce;

import java.util.ArrayList;
import java.util.List;

public class NumbersSummationReduce {

    private static List<Integer> list() {
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0 ; i <= 100 ; i ++ ) {
            list.add(i);
        }
        return list;
    }

    public static void main(String[] args) {
        List<Integer> list = list();
        int summation = 0;
        Integer result = list.stream().reduce(summation, (x, y) -> {
            System.out.println("x = " + x + "; y = " + y);
            return x + y;
        });
        System.out.println(result);
    }

}
