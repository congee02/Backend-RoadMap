package com.congee02.employee;

import com.congee02.employee.entity.Employee;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class EmployeeManagement {

    private static Collection<Employee> employeeCollection() {
        List<Employee> employees = new ArrayList<>();

        employees.add(new Employee("大壮", "上海公司", "研发一部", 28, 3000));
        employees.add(new Employee("二牛", "上海公司", "研发一部", 24, 2000));
        employees.add(new Employee("铁柱", "上海公司", "研发二部", 34, 5000));
        employees.add(new Employee("翠花", "南京公司", "测试一部", 27, 3000));
        employees.add(new Employee("玲玲", "南京公司", "测试二部", 31, 4000));

        return employees;
    }

    /**
     * 现有集团内所有人员列表，需要从中筛选出上海子公司的全部人员
     */
    public static List<Employee> filterEmployeesBySubCompany() {
        return employeeCollection().stream()
                .filter(employee -> "上海公司".equals(employee.getSubCompany()))
                .collect(Collectors.toList());
    }

    /**
     * 现有集团内所有人员列表，需要从中筛选出上海子公司的全部人员，并按照部门进行分组
     */
    public static Map<String, List<Employee>> filterEmployeeBySubCompanyAndDepartment() {
        return employeeCollection().stream()
                .filter(employee -> "上海公司".equals(employee.getSubCompany()))
                .collect(Collectors.groupingBy(Employee::getDepartment));
    }

    /**
     * 计算上海子公司每个月需要支付的员工总工资
     */
    private static int shanghaiSubCompanySalarySum() {
        return employeeCollection().stream()
                .filter(employee -> "上海公司".equals(employee.getSubCompany()))
                .collect(Collectors.summingInt(employee -> employee.getSalary()));
    }

    /**
     * 按照子公司维度将员工分组
     */
    private static Map<String, List<Employee>> groupBySubCompany() {
        return employeeCollection().stream()
                .collect(Collectors.groupingBy(Employee::getSubCompany))    // 值收集器默认为 toList()
                ;
    }


    /**
     * 按照子公司分组，统计每个子公司的员工数量
     */
    private static Map<String, Long> groupBySubCompanyThenCount() {
        return employeeCollection().stream()
                .collect(
                        Collectors.groupingBy(
                                Employee::getSubCompany,
                                Collectors.counting()
                        )
                );
    }

    /**
     * 现有整个集团全体员工的列表，需要统计各子公司内各部门下的员工人数。
     */
    private static Map<String, Map<String, Long>> groupBySubCompanyAndSectionThenCount() {
        return employeeCollection().stream().collect(
                Collectors.groupingBy(
                        Employee::getSubCompany,
                        Collectors.groupingBy(
                                Employee::getDepartment,
                                Collectors.counting()
                        )
                ));
    }

    /**
     * 给定集团所有员工列表，找出上海公司中工资最高的员工。
     */
    private static Employee findShanghaiHighestSalaryEmployee() {
        return employeeCollection().stream().filter(e -> "上海公司".equals(e.getSubCompany())).collect(
                Collectors.collectingAndThen(
                        Collectors.maxBy(Comparator.comparingInt(Employee::getSalary)),
                        Optional::orElseThrow
                )
        );
    }




    public static void main(String[] args) {
        System.out.println(filterEmployeesBySubCompany());
        System.out.println(filterEmployeeBySubCompanyAndDepartment());
        System.out.println(groupBySubCompany());
        System.out.println(shanghaiSubCompanySalarySum());
        System.out.println(groupBySubCompanyThenCount());
        System.out.println(groupBySubCompanyAndSectionThenCount());
        System.out.println(findShanghaiHighestSalaryEmployee());
    }

}
