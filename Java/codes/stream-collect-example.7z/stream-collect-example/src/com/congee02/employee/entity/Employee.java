package com.congee02.employee.entity;

public class Employee {
    private String name;
    private String subCompany;
    private String department;
    private int age;
    private int salary;

    // 构造函数
    public Employee(String name, String subsidiary, String department, int age, int salary) {
        this.name = name;
        this.subCompany = subsidiary;
        this.department = department;
        this.age = age;
        this.salary = salary;
    }

    // Getter 和 Setter 方法
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubCompany() {
        return subCompany;
    }

    public void setSubCompany(String subCompany) {
        this.subCompany = subCompany;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", subCompany='" + subCompany + '\'' +
                ", department='" + department + '\'' +
                ", age=" + age +
                ", salary=" + salary +
                '}';
    }
}