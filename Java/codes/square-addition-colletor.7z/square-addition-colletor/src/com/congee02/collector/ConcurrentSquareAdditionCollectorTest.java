package com.congee02.collector;

import java.util.List;

class ConcurrentSquareAdditionCollectorTest {

    public static void main(String[] args) {
        System.out.println(List.of(1, 2, 3, 4, 5).stream().collect(new ConcurrentSquareAdditionCollector()));
    }

}