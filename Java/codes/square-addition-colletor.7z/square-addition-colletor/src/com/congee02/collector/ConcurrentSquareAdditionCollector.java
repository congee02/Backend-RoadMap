package com.congee02.collector;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collector;

public final class ConcurrentSquareAdditionCollector implements Collector<Integer, AtomicInteger, Integer> {
    @Override
    public Supplier<AtomicInteger> supplier() {
        return () -> new AtomicInteger(0);
    }

    @Override
    public BiConsumer<AtomicInteger, Integer> accumulator() {
        return (acc, current) -> {
            acc.addAndGet(current * current);
        };
    }

    @Override
    public BinaryOperator<AtomicInteger> combiner() {
        return (firstSum, secondSum) -> {
            firstSum.addAndGet(secondSum.get());
            return firstSum;
        };
    }

    @Override
    public Function<AtomicInteger, Integer> finisher() {
        return AtomicInteger::get;
    }

    @Override
    public Set<Characteristics> characteristics() {
        return Collections.unmodifiableSet(
                EnumSet.of(
                        Characteristics.CONCURRENT,
                        Characteristics.UNORDERED
                )
        );
    }
}
